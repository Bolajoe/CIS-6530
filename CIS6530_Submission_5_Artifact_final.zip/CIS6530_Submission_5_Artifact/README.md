# CIS 6530 Submission 5 Package

## Overview

This package contains the implementation, results, figures, report, and run instructions for Submission 5, which adapts the CNN method from McLaughlin et al., *Deep Android Malware Detection* (CODASPY 2017), to APT-labelled OpCode sequences extracted in the earlier course submissions.

The implemented model uses the following flow:

Input tokens -> Embedding(dim=8) -> Conv1D(64 filters, kernel=8) -> ReLU -> Global MaxPool -> Dense(16) -> ReLU -> Dense(29 classes) -> Softmax

The package also includes the Submission 4 comparison outputs used for the controlled baseline analysis.

## Package Contents

```text
Submission_5_Artifacts/
├── scripts/
│   ├── config.py
│   ├── utils.py
│   ├── 01_build_manifest.py
│   ├── 02_preprocess_sequences.py
│   ├── 03_train_eval_deep_model_cv.py
│   ├── 04_plot_confusion.py
│   ├── 05_compare_to_baselines.py
│   ├── 06_generate_report_pdf.py
│   ├── 07_make_final_zip.py
│   ├── 08_plot_training_curves.py
│   └── 09_embed_curves_into_report.py
├── data_processed/
├── results/
├── report/
│   ├── CIS6530_Submission5_Technical_Report.docx
│   ├── CIS6530_Submission5_Technical_Report.pdf
│   └── figures/
├── README.md
├── RUN_INSTRUCTIONS.md
├── run_all.sh
└── requirements.txt
```

## Key Results

| Model | Features | Accuracy | Macro-F1 |
|---|---|---:|---:|
| Linear SVM (LinearSVC) | 2-gram | 0.2546 | 0.1775 |
| Decision Tree | 2-gram | 0.2207 | 0.1925 |
| KNN (k=3) | 1-gram | 0.1011 | 0.0601 |
| DeepOpcodeCNN | sequence | 0.0506 | 0.0070 |

Best accuracy baseline: Linear SVM (implemented with scikit-learn LinearSVC) with 2-gram features.  
Best macro-F1 baseline: Decision Tree with 2-gram features.

## Reproducibility Position

The package includes the scripts, processed data, results, report, and dependency list required to reproduce the packaged workflow. The same seed, fold structure, and evaluation metrics used in Submission 4 are preserved for the controlled comparison. Minor numerical variation can still occur across environments because of platform and library differences.

## Submission Files

Use the files in `report/` as the authoritative report deliverables:
- `CIS6530_Submission5_Technical_Report.docx`
- `CIS6530_Submission5_Technical_Report.pdf`


LinearSVC is the scikit-learn implementation of a linear SVM, so it satisfies the rubric's SVM baseline requirement.
