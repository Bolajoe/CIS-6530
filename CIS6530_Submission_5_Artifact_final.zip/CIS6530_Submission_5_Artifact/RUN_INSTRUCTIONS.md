# Run Instructions - CIS 6530 Submission 5

## 1. Environment

Requirements:
- Python 3.9 or later
- Virtual environment recommended
- CPU is sufficient for this dataset; GPU is optional

Create and activate the environment:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

On Windows PowerShell, activate with:

```powershell
.venv\Scripts\Activate.ps1
```

## 2. Configure Paths

Open `scripts/config.py` and set the required source paths:

```python
SUB3_OUTPUT = Path(r"/path/to/SUBMISSION_3_OUTPUT")
SUB2_ROOT = Path(r"/path/to/CIS_6530_Assignment_Submission_2")
```

If the Submission 4 summary CSV is available, set `SUB4_SUMMARY_CSV` to that file. If it is not available, the packaged fallback comparison CSV is used.

## 3. Execute the Pipeline

Run the scripts from the package root in the following order:

```bash
python3 -m scripts.01_build_manifest
python3 -m scripts.02_preprocess_sequences
python3 -m scripts.03_train_eval_deep_model_cv
python3 -m scripts.04_plot_confusion
python3 -m scripts.05_compare_to_baselines
python3 -m scripts.06_generate_report_pdf
python3 -m scripts.07_make_final_zip
```

The same sequence can be launched with:

```bash
bash run_all.sh
```

## 4. Expected Outputs

The core outputs are:

- `results/deep_metrics.json`
- `results/deep_predictions.jsonl`
- `results/confusion_DeepOpcodeCNN.png`
- `results/comparison_table.csv`
- `report/CIS6530_Submission5_Technical_Report.pdf`

## 5. Optional Logged Curves

To generate true logged training curves, run:

```bash
python3 -m scripts.03_train_eval_deep_model_cv --log-history
python3 -m scripts.08_plot_training_curves
```

If a separate report template is available and you want to embed the logged curves into that document, script `09_embed_curves_into_report.py` can be run with explicit input and output paths supplied by the user.

## 6. Notes

- All fold splitting uses `random_state=42`.
- The deep model applies class weighting on the training fold only.
- Long sequences are capped at `MAX_SEQ_LEN=20_000`.
- Minor numerical variation can occur across environments.


## 7. Baseline Naming Note

The Submission 4 SVM baseline is implemented with `LinearSVC`, which is scikit-learn's linear support vector machine classifier. In the report, this is referred to as the linear SVM baseline or as `LinearSVC` where the implementation detail matters.
