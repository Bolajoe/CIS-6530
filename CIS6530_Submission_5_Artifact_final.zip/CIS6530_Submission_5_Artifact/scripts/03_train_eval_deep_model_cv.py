#!/usr/bin/env python3
"""
03_train_eval_deep_model_cv.py — Train and evaluate the DeepOpcodeCNN
======================================================================
Implements the CNN architecture from McLaughlin et al., "Deep Android
Malware Detection," CODASPY 2017, adapted to multi-class APT-labelled
OpCode sequences.

Architecture (faithful to paper)
----------------------------------
    Input tokens → Embedding(dim=8) → Conv1D(64 filters, kernel=8)
    → ReLU → Global MaxPool → Dense(16) → ReLU → Dense(n_classes)
    → Softmax (via CrossEntropyLoss)

Training protocol
-----------------
    Optimizer : RMSprop (lr=0.01)
    Epochs    : 10
    Batch     : 16
    Loss      : CrossEntropy with inverse-frequency class weights (training fold)
    CV        : StratifiedKFold(n_splits=2, shuffle=True, random_state=42)

Sequence length adaptation
--------------------------
OpCode sequences can reach ~500,000 tokens. Padding full-length batches
exhausts RAM. Sequences are capped at MAX_SEQ_LEN=20,000:
    Train : random contiguous window  (data augmentation effect, seeded)
    Eval  : head window               (deterministic for reproducibility)

Outputs
-------
    results/deep_metrics.json
    results/deep_summary_row.csv
    results/deep_predictions.jsonl

Usage
-----
    python3 -m scripts.03_train_eval_deep_model_cv   (run after 02)

Course    : CIS 6530 — Cybersecurity and Threat Intelligence
Submission: 5 — Deep Method
"""

import json
import argparse
import sys

LOG_HISTORY = ('--log-history' in sys.argv)

import random

import numpy as np
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import (
    accuracy_score,
    precision_recall_fscore_support,
    confusion_matrix,
)

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader

from scripts import config as cfg
from scripts.utils import ensure_dir


# ── Reproducibility ──────────────────────────────────────────────────────────

def set_seed(seed: int) -> None:
    """Fix all random seeds for reproducibility."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


# ── Dataset ──────────────────────────────────────────────────────────────────

class SeqDataset(Dataset):
    """Minimal PyTorch Dataset wrapping opcode integer sequences."""
    def __init__(self, seqs: list, y: np.ndarray, ids: list) -> None:
        self.seqs = seqs
        self.y    = y
        self.ids  = ids

    def __len__(self) -> int:
        return len(self.seqs)

    def __getitem__(self, idx):
        return self.seqs[idx], int(self.y[idx]), self.ids[idx]


def crop_seq(seq: list, train: bool) -> list:
    """Crop a sequence to MAX_SEQ_LEN.

    Train  : random window (augmentation, controlled by global random state).
    Eval   : head window  (deterministic).
    """
    if len(seq) <= cfg.MAX_SEQ_LEN:
        return seq
    if train:
        start = random.randint(0, len(seq) - cfg.MAX_SEQ_LEN)
        return seq[start: start + cfg.MAX_SEQ_LEN]
    return seq[: cfg.MAX_SEQ_LEN]


def make_collate(train: bool):
    """Return a collate function for DataLoader that crops and pads sequences."""
    def collate(batch):
        seqs, ys, ids = zip(*batch)
        seqs     = [crop_seq(list(s), train=train) for s in seqs]
        max_len  = max(len(s) for s in seqs) if seqs else 0
        max_len  = max(max_len, cfg.KERNEL_SIZE)   # conv requires len >= kernel_size
        padded   = [s + [0] * (max_len - len(s)) for s in seqs]
        x = torch.tensor(padded, dtype=torch.long)
        y = torch.tensor(ys,     dtype=torch.long)
        return x, y, list(ids)
    return collate


# ── Model ────────────────────────────────────────────────────────────────────

class DeepOpcodeCNN(nn.Module):
    """CNN for opcode sequence classification.

    Faithfully implements the architecture described in McLaughlin et al. [1]:
        Embedding → Conv1D → ReLU → Global MaxPool → Dense(16) → ReLU → Dense(C)
    """
    def __init__(self, vocab_size: int, n_classes: int) -> None:
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, cfg.EMBED_DIM, padding_idx=0)
        self.conv      = nn.Conv1d(cfg.EMBED_DIM, cfg.N_FILTERS, kernel_size=cfg.KERNEL_SIZE)
        self.relu      = nn.ReLU()
        self.fc1       = nn.Linear(cfg.N_FILTERS, cfg.HIDDEN_UNITS)
        self.fc2       = nn.Linear(cfg.HIDDEN_UNITS, n_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        emb = self.embedding(x).transpose(1, 2)   # (B, E, L)
        z   = self.relu(self.conv(emb))            # (B, F, L')
        z   = torch.max(z, dim=2).values           # (B, F)  — global max pool
        h   = self.relu(self.fc1(z))               # (B, 16)
        return self.fc2(h)                          # (B, C)


# ── Training helpers ─────────────────────────────────────────────────────────

def class_weights(y: np.ndarray, n_classes: int) -> np.ndarray:
    """Inverse-frequency class weights normalised so they sum to n_classes."""
    counts = np.bincount(y, minlength=n_classes).astype(np.float32)
    w      = 1.0 / np.maximum(counts, 1.0)
    return w * (n_classes / w.sum())


def train_epoch(model, loader, device, loss_fn, opt):
    """Run one training epoch; return (mean_loss, train_acc)."""
    model.train()
    total = 0.0
    correct = 0
    total_n = 0
    for x, y, _ in loader:
        x = x.to(device)
        y = y.to(device)
        opt.zero_grad()
        loss = loss_fn(model(x), y)
        loss.backward()
        opt.step()
        total += float(loss.item())
        pred = torch.argmax(model(x), dim=1)
        correct += int((pred == y).sum().item())
        total_n += int(y.numel())
    mean_loss = total / max(1, len(loader))
    return float(mean_loss), float(correct / max(1, total_n))


@torch.no_grad()
def predict(model, loader, device):
    """Run inference; return (y_true, y_pred, sample_ids)."""
    model.eval()
    ys, ps, ids = [], [], []
    for x, y, bids in loader:
        x    = x.to(device)
        pred = torch.argmax(model(x), dim=1).cpu().numpy()
        ys.append(y.numpy())
        ps.append(pred)
        ids.extend(bids)
    return np.concatenate(ys), np.concatenate(ps), ids

@torch.no_grad()
def eval_epoch(model, loader, device, loss_fn):
    """Evaluate loss and accuracy on a loader (no gradients)."""
    model.eval()
    total_loss = 0.0
    correct = 0
    total_n = 0
    for x, y, _ in loader:
        x = x.to(device)
        y = y.to(device)
        logits = model(x)
        loss = loss_fn(logits, y)
        total_loss += float(loss.item())
        pred = torch.argmax(logits, dim=1)
        correct += int((pred == y).sum().item())
        total_n += int(y.numel())
    mean_loss = total_loss / max(1, len(loader))
    acc = correct / max(1, total_n)
    return float(mean_loss), float(acc)




# ── Cross-validation runner ──────────────────────────────────────────────────

def load_sequences():
    """Load ids, labels, vocabulary, and integer sequences from disk."""
    ids      = json.loads((cfg.DATA_PROCESSED_DIR / "ids.json").read_text(encoding="utf-8"))
    y        = np.load(cfg.DATA_PROCESSED_DIR / "y.npy")
    vocab    = json.loads((cfg.DATA_PROCESSED_DIR / "vocab.json").read_text(encoding="utf-8"))
    id_to_seq: dict = {}
    with (cfg.DATA_PROCESSED_DIR / "sequences.jsonl").open("r", encoding="utf-8") as f:
        for line in f:
            obj = json.loads(line)
            id_to_seq[obj["sample_id"]] = obj["seq"]
    seqs = [id_to_seq[sid] for sid in ids]
    return ids, y, vocab, seqs


def main() -> None:
    ensure_dir(cfg.RESULTS_DIR)
    set_seed(cfg.RANDOM_SEED)

    ids, y, vocab, seqs = load_sequences()
    label_map = json.loads(
        (cfg.DATA_PROCESSED_DIR / "label_encoder.json").read_text(encoding="utf-8")
    )
    labels    = [label_map[str(i)] for i in range(len(label_map))]
    n_classes = len(labels)
    vocab_size= len(vocab)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"[+] Device      : {device}")
    print(f"[+] Samples     : {len(y)}  |  Classes: {n_classes}  |  Vocab: {vocab_size}")
    print(f"[+] Architecture: Embedding({vocab_size},{cfg.EMBED_DIM}) → "
          f"Conv1D({cfg.N_FILTERS},k={cfg.KERNEL_SIZE}) → MaxPool → "
          f"Dense({cfg.HIDDEN_UNITS}) → Dense({n_classes})")
    print(f"[+] Training    : {cfg.OPTIMIZER} lr={cfg.LEARNING_RATE}, "
          f"epochs={cfg.EPOCHS}, batch={cfg.BATCH_SIZE}, MAX_SEQ_LEN={cfg.MAX_SEQ_LEN}")
    print()

    skf = StratifiedKFold(
        n_splits=cfg.N_SPLITS, shuffle=True, random_state=cfg.RANDOM_SEED
    )

    fold_rows:  list = []
    cm_sum            = None
    pred_path         = cfg.RESULTS_DIR / "deep_predictions.jsonl"
    if pred_path.exists():
        pred_path.unlink()

    for fold_idx, (tr, te) in enumerate(skf.split(np.zeros(len(y)), y), start=1):
        print(f"[Fold {fold_idx}/{cfg.N_SPLITS}]  train={len(tr)}  test={len(te)}")

        model  = DeepOpcodeCNN(vocab_size, n_classes).to(device)
        w      = class_weights(y[tr], n_classes)
        loss_fn= nn.CrossEntropyLoss(
            weight=torch.tensor(w, dtype=torch.float32, device=device)
        )
        opt    = torch.optim.RMSprop(model.parameters(), lr=cfg.LEARNING_RATE)

        train_ds = SeqDataset([seqs[i] for i in tr], y[tr], [ids[i] for i in tr])
        test_ds  = SeqDataset([seqs[i] for i in te], y[te], [ids[i] for i in te])

        train_loader = DataLoader(
            train_ds, batch_size=cfg.BATCH_SIZE, shuffle=True,
            collate_fn=make_collate(train=True)
        )
        test_loader = DataLoader(
            test_ds, batch_size=cfg.BATCH_SIZE, shuffle=False,
            collate_fn=make_collate(train=False)
        )

        history_rows = []
        for epoch in range(1, cfg.EPOCHS + 1):
            train_loss, train_acc = train_epoch(model, train_loader, device, loss_fn, opt)
            if LOG_HISTORY:
                test_loss, test_acc = eval_epoch(model, test_loader, device, loss_fn)
                history_rows.append({
                    "epoch": int(epoch),
                    "train_loss": float(train_loss),
                    "train_acc": float(train_acc),
                    "test_loss": float(test_loss),
                    "test_acc": float(test_acc),
                })
                if epoch == 1 or epoch == cfg.EPOCHS or epoch % 2 == 0:
                    print(f"  epoch {epoch:>2}/{cfg.EPOCHS}  loss={train_loss:.4f}  tr_acc={train_acc:.3f}  te_acc={test_acc:.3f}")
            else:
                if epoch == 1 or epoch == cfg.EPOCHS or epoch % 2 == 0:
                    print(f"  epoch {epoch:>2}/{cfg.EPOCHS}  loss={train_loss:.4f}")
        if LOG_HISTORY and history_rows:
            import csv
            from pathlib import Path
            hist_csv = Path(cfg.RESULTS_DIR) / f"training_history_fold{fold_idx}.csv"
            with hist_csv.open("w", newline="", encoding="utf-8") as cf:
                writer = csv.DictWriter(cf, fieldnames=list(history_rows[0].keys()))
                writer.writeheader()
                writer.writerows(history_rows)

        y_true, y_pred, id_list = predict(model, test_loader, device)
        acc  = float(accuracy_score(y_true, y_pred))
        prec, rec, f1, _ = precision_recall_fscore_support(
            y_true, y_pred, average="macro", zero_division=0
        )
        print(f"  → acc={acc:.4f}  prec={prec:.4f}  rec={rec:.4f}  f1={f1:.4f}")

        fold_rows.append({
            "fold": fold_idx,
            "accuracy":        acc,
            "macro_precision": float(prec),
            "macro_recall":    float(rec),
            "macro_f1":        float(f1),
            "n_test":          int(len(y_true)),
        })

        cm     = confusion_matrix(y_true, y_pred, labels=np.arange(n_classes))
        cm_sum = cm if cm_sum is None else (cm_sum + cm)

        with pred_path.open("a", encoding="utf-8") as f:
            for sid, yt, yp in zip(id_list, y_true.tolist(), y_pred.tolist()):
                f.write(json.dumps({"fold": fold_idx, "sample_id": sid,
                                    "y_true": yt, "y_pred": yp}) + "\n")

    accs  = np.array([r["accuracy"]        for r in fold_rows], dtype=float)
    precs = np.array([r["macro_precision"]  for r in fold_rows], dtype=float)
    recs  = np.array([r["macro_recall"]     for r in fold_rows], dtype=float)
    f1s   = np.array([r["macro_f1"]         for r in fold_rows], dtype=float)

    summary = {
        "method":       "Deep Android Malware Detection (adapted to OpCodes)",
        "reference":    "McLaughlin et al., CODASPY 2017",
        "architecture": {
            "embedding_dim": cfg.EMBED_DIM,
            "conv_filters":  cfg.N_FILTERS,
            "kernel_size":   cfg.KERNEL_SIZE,
            "hidden_units":  cfg.HIDDEN_UNITS,
        },
        "training": {
            "optimizer":       cfg.OPTIMIZER,
            "learning_rate":   cfg.LEARNING_RATE,
            "epochs":          cfg.EPOCHS,
            "batch_size":      cfg.BATCH_SIZE,
            "class_weighting": "inverse-frequency weights on training fold",
            "max_seq_len":     cfg.MAX_SEQ_LEN,
            "windowing":       {"train": "random window", "eval": "head window"},
        },
        "evaluation": {
            "cv_strategy": "StratifiedKFold",
            "cv_folds":    cfg.N_SPLITS,
            "shuffle":     True,
            "random_seed": cfg.RANDOM_SEED,
        },
        "data": {
            "n_samples": int(len(y)),
            "n_classes": int(n_classes),
            "vocab_size":int(vocab_size),
        },
        "folds": fold_rows,
        "mean": {
            "accuracy":        float(accs.mean()),
            "macro_precision": float(precs.mean()),
            "macro_recall":    float(recs.mean()),
            "macro_f1":        float(f1s.mean()),
        },
        "std": {
            "accuracy":        float(accs.std(ddof=0)),
            "macro_precision": float(precs.std(ddof=0)),
            "macro_recall":    float(recs.std(ddof=0)),
            "macro_f1":        float(f1s.std(ddof=0)),
        },
        "confusion_matrix_sum": cm_sum.tolist() if cm_sum is not None else None,
    }

    (cfg.RESULTS_DIR / "deep_metrics.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )
    (cfg.RESULTS_DIR / "deep_summary_row.csv").write_text(
        "model,mean_accuracy,std_accuracy,mean_macro_precision,mean_macro_recall,mean_macro_f1\n"
        f"DeepOpcodeCNN,"
        f"{summary['mean']['accuracy']},{summary['std']['accuracy']},"
        f"{summary['mean']['macro_precision']},{summary['mean']['macro_recall']},"
        f"{summary['mean']['macro_f1']}\n",
        encoding="utf-8",
    )

    print()
    print("[+] Wrote results/deep_metrics.json")
    print("[+] Wrote results/deep_summary_row.csv")
    print(f"[+] Final mean: acc={accs.mean():.4f}  F1={f1s.mean():.4f}")


if __name__ == "__main__":
    main()
