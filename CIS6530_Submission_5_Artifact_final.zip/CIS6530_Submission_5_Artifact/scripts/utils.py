"""utils.py — Shared helpers for CIS 6530 Submission 5."""
from pathlib import Path

def ensure_dir(p: Path) -> None:
    """Create directory p and all parents if they do not exist."""
    p.mkdir(parents=True, exist_ok=True)
