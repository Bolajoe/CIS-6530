#!/usr/bin/env python3
"""Embed generated training/testing curve images into the hybrid v11 DOCX report.

Searches for placeholders:
    [[INSERT_TRAINING_LOSS_CURVE]]
    [[INSERT_TRAINING_ACCURACY_CURVE]]

and replaces them with images from report/figures/.
"""
import argparse
from pathlib import Path
from docx import Document
from docx.shared import Inches
import scripts.config as cfg

def replace_placeholder_with_image(doc, placeholder, image_path, width=6.5):
    for p in doc.paragraphs:
        if placeholder in p.text:
            # Clear paragraph text
            for run in p.runs:
                run.text = ""
            r = p.add_run()
            r.add_picture(str(image_path), width=Inches(width))
            return True
    return False

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="in_docx", required=True)
    ap.add_argument("--out", dest="out_docx", required=True)
    args = ap.parse_args()

    in_path = Path(args.in_docx)
    out_path = Path(args.out_docx)

    fig_dir = Path(cfg.REPORT_DIR) / "figures"
    loss_img = fig_dir / "fig_training_loss_curve_TRUE.png"
    acc_img  = fig_dir / "fig_training_accuracy_curve_TRUE.png"

    if not loss_img.exists() or not acc_img.exists():
        raise SystemExit("Curve images not found. Run: python3 -m scripts.08_plot_training_curves")

    doc = Document(str(in_path))
    ok1 = replace_placeholder_with_image(doc, "[[INSERT_TRAINING_LOSS_CURVE]]", loss_img)
    ok2 = replace_placeholder_with_image(doc, "[[INSERT_TRAINING_ACCURACY_CURVE]]", acc_img)

    if not (ok1 and ok2):
        raise SystemExit("Placeholders not found in document. Ensure the hybrid v11 template is used.")

    doc.save(str(out_path))
    print("[+] Wrote:", out_path)

if __name__ == "__main__":
    main()
