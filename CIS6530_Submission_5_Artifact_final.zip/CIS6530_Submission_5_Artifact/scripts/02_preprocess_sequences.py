#!/usr/bin/env python3
"""
02_preprocess_sequences.py — Parse .opcode files into integer token sequences
==============================================================================
Reads the manifest, parses each .opcode file into a clean mnemonic token list,
builds a global vocabulary (token → integer id), filters classes with
insufficient samples for stratified cross-validation, and saves:

    - Integer-encoded sequences in JSONL format
    - Vocabulary mapping (vocab.json)
    - Label encoder (label_encoder.json)
    - Sequence statistics (sequence_stats.json)

Parsing rules (matches Submission 4 for consistency)
-----------------------------------------------------
    • Lines starting with '#' (disassembler metadata) → discarded
    • Lines equal to '<FUNCTION>' (boundary markers)  → discarded
    • All other non-empty lines                        → mnemonic tokens

Class filtering
---------------
Labels with < N_SPLITS (= 2) samples are excluded before training.
This is required by StratifiedKFold: every fold must contain at least
one instance of each class. Excluded labels are logged to
data_processed/filtered_out_classes.csv.

Outputs
-------
    data_processed/ids.json
    data_processed/y.npy
    data_processed/label_encoder.json
    data_processed/vocab.json               (includes <PAD>=0)
    data_processed/sequences.jsonl
    data_processed/sequence_stats.json
    data_processed/filtered_out_classes.csv
    data_processed/class_counts.csv

Usage
-----
    python3 -m scripts.02_preprocess_sequences   (run after 01)

Course    : CIS 6530 — Cybersecurity and Threat Intelligence
Submission: 5 — Deep Method
"""

import csv
import json
from collections import Counter
from pathlib import Path

import numpy as np
from sklearn.preprocessing import LabelEncoder

from scripts import config as cfg
from scripts.utils import ensure_dir


def load_tokens(path: Path) -> list:
    """Return a list of mnemonic token strings from a .opcode file."""
    tokens: list = []
    for line in path.read_text(errors="ignore").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or line.startswith("<FUNCTION>"):
            continue
        tokens.append(line)
    return tokens


def main() -> None:
    ensure_dir(cfg.DATA_PROCESSED_DIR)

    manifest = cfg.DATA_PROCESSED_DIR / "manifest.csv"
    if not manifest.exists():
        raise FileNotFoundError(
            "manifest.csv not found. Run: python3 -m scripts.01_build_manifest"
        )

    rows = list(csv.DictReader(manifest.open("r", encoding="utf-8")))

    # ── Class filtering ──────────────────────────────────────────────────────
    label_counts: Counter = Counter(r["label"] for r in rows)
    keep_labels = {lab for lab, c in label_counts.items() if c >= cfg.N_SPLITS}
    drop_labels = {lab for lab, c in label_counts.items() if c <  cfg.N_SPLITS}

    kept    = [r for r in rows if r["label"] in keep_labels]
    dropped = [r for r in rows if r["label"] in drop_labels]

    out_dropped = cfg.DATA_PROCESSED_DIR / "filtered_out_classes.csv"
    with out_dropped.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["sample_id", "label", "opcode_path"])
        for r in dropped:
            w.writerow([r["sample_id"], r["label"], r["opcode_path"]])

    out_counts = cfg.DATA_PROCESSED_DIR / "class_counts.csv"
    with out_counts.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["label", "count", "kept"])
        for lab, c in sorted(label_counts.items(), key=lambda x: (-x[1], x[0])):
            w.writerow([lab, c, "yes" if lab in keep_labels else "no"])

    print(f"[+] Total samples   : {len(rows)}")
    print(f"[+] Kept samples    : {len(kept)}  (labels with n >= {cfg.N_SPLITS})")
    print(f"[!] Filtered samples: {len(dropped)} — labels: {sorted(drop_labels)}")

    # ── Build vocabulary and encode sequences ────────────────────────────────
    vocab: dict = {"<PAD>": 0}
    next_id = 1

    ids: list     = []
    labels: list  = []
    lengths: list = []
    raw_seqs: list = []

    for r in kept:
        tokens = load_tokens(Path(r["opcode_path"]))
        seq: list = []
        for tok in tokens:
            if tok not in vocab:
                vocab[tok] = next_id
                next_id += 1
            seq.append(vocab[tok])
        ids.append(r["sample_id"])
        labels.append(r["label"])
        raw_seqs.append(seq)
        lengths.append(len(seq))

    le = LabelEncoder()
    y  = le.fit_transform(labels)

    np.save(cfg.DATA_PROCESSED_DIR / "y.npy", y)
    (cfg.DATA_PROCESSED_DIR / "ids.json").write_text(
        json.dumps(ids, indent=2), encoding="utf-8"
    )
    label_map = {int(i): cls for i, cls in enumerate(le.classes_)}
    (cfg.DATA_PROCESSED_DIR / "label_encoder.json").write_text(
        json.dumps(label_map, indent=2), encoding="utf-8"
    )
    (cfg.DATA_PROCESSED_DIR / "vocab.json").write_text(
        json.dumps(vocab, indent=2), encoding="utf-8"
    )

    seq_path = cfg.DATA_PROCESSED_DIR / "sequences.jsonl"
    with seq_path.open("w", encoding="utf-8") as f:
        for sid, seq in zip(ids, raw_seqs):
            f.write(json.dumps({"sample_id": sid, "seq": seq}) + "\n")

    stats = {
        "n_samples":  len(ids),
        "n_classes":  int(len(le.classes_)),
        "vocab_size": int(len(vocab)),
        "min_len":    int(min(lengths)  if lengths else 0),
        "median_len": float(sorted(lengths)[len(lengths) // 2] if lengths else 0),
        "max_len":    int(max(lengths)  if lengths else 0),
    }
    (cfg.DATA_PROCESSED_DIR / "sequence_stats.json").write_text(
        json.dumps(stats, indent=2), encoding="utf-8"
    )

    print(f"[+] Vocabulary size : {len(vocab)}")
    print(f"[+] Sequence stats  : {stats}")
    print(f"[+] Saved sequences to {seq_path}")


if __name__ == "__main__":
    main()
