#!/usr/bin/env python3
"""Plot true training/testing curves from logged history CSVs."""
import glob
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
import scripts.config as cfg

def main():
    hist_files = sorted(glob.glob(str(Path(cfg.RESULTS_DIR) / "training_history_fold*.csv")))
    if not hist_files:
        raise SystemExit("No training_history_fold*.csv found. Run: python3 -m scripts.03_train_eval_deep_model_cv --log-history")

    dfs = [pd.read_csv(f) for f in hist_files]
    df = pd.concat(dfs, ignore_index=True)
    agg = df.groupby("epoch").mean(numeric_only=True).reset_index()

    fig_dir = Path(cfg.REPORT_DIR) / "figures"
    fig_dir.mkdir(parents=True, exist_ok=True)

    # Loss curves
    plt.figure()
    plt.plot(agg["epoch"], agg["train_loss"], label="Train loss")
    plt.plot(agg["epoch"], agg["test_loss"], label="Test loss")
    plt.xlabel("Epoch"); plt.ylabel("Loss")
    plt.title("DeepOpcodeCNN Loss Curves (mean across folds)")
    plt.legend()
    plt.grid(True, linestyle="--", linewidth=0.5)
    plt.tight_layout()
    plt.savefig(fig_dir / "fig_training_loss_curve_TRUE.png", dpi=200)
    plt.close()

    # Accuracy curves
    plt.figure()
    plt.plot(agg["epoch"], agg["train_acc"], label="Train accuracy")
    plt.plot(agg["epoch"], agg["test_acc"], label="Test accuracy")
    plt.xlabel("Epoch"); plt.ylabel("Accuracy")
    plt.title("DeepOpcodeCNN Train vs Test Accuracy (mean across folds)")
    plt.legend()
    plt.grid(True, linestyle="--", linewidth=0.5)
    plt.tight_layout()
    plt.savefig(fig_dir / "fig_training_accuracy_curve_TRUE.png", dpi=200)
    plt.close()

    print("[+] Wrote curves to", fig_dir)

if __name__ == "__main__":
    main()
