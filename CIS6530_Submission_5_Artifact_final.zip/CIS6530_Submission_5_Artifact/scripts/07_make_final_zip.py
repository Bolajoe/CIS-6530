#!/usr/bin/env python3
"""
07_make_final_zip.py — Package all deliverables into the submission ZIP
========================================================================
Output: Submission_5_Artifacts.zip

Usage
-----
    python3 -m scripts.07_make_final_zip   (run after all other scripts)

Course    : CIS 6530 — Cybersecurity and Threat Intelligence
Submission: 5 — Deep Method
"""

import zipfile
from pathlib import Path
from scripts import config as cfg

EXCLUDE = {"__pycache__", ".pyc", ".pyo", ".DS_Store"}


def should_include(p: Path) -> bool:
    return not any(ex in str(p) for ex in EXCLUDE)


def add_dir(z: zipfile.ZipFile, folder: Path, prefix: str) -> int:
    count = 0
    for p in sorted(folder.rglob("*")):
        if p.is_file() and should_include(p):
            z.write(p, str(Path(prefix) / p.relative_to(folder)))
            count += 1
    return count


def main() -> None:
    out = cfg.PROJECT_ROOT / "Submission_5_Artifacts.zip"
    if out.exists():
        out.unlink()

    total = 0
    with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for folder, prefix in [
            (cfg.PROJECT_ROOT / "scripts",  "scripts"),
            (cfg.DATA_PROCESSED_DIR,         "data_processed"),
            (cfg.RESULTS_DIR,                "results"),
            (cfg.REPORT_DIR,                 "report"),
        ]:
            if folder.exists():
                n = add_dir(z, folder, prefix)
                total += n
                print(f"[+] {prefix:<14}: {n} file(s)")
        for fname in ["README.md", "RUN_INSTRUCTIONS.md", "requirements.txt", "run_all.sh"]:
            p = cfg.PROJECT_ROOT / fname
            if p.exists():
                z.write(p, fname)
                total += 1
                print(f"[+] {fname}")

    mb = out.stat().st_size / (1024 * 1024)
    print(f"\n[+] Wrote {out}  ({mb:.2f} MB, {total} files)")


if __name__ == "__main__":
    main()
