#!/usr/bin/env python3
"""
06_generate_report_pdf.py — Generate the Submission 5 technical report PDF
===========================================================================
Produces a structured PDF report covering implementation, evaluation, and
comparison to Submission 4 baselines.

Output
------
    report/CIS6530_Submission5_Technical_Report.pdf

Usage
-----
    python3 -m scripts.06_generate_report_pdf   (run after 05)

Course    : CIS 6530 — Cybersecurity and Threat Intelligence
Submission: 5 — Deep Method
"""

import csv
import json
from pathlib import Path

from reportlab.lib.pagesizes import letter
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    PageBreak, HRFlowable,
)

from scripts import config as cfg


# ── Helpers ──────────────────────────────────────────────────────────────────

def read_csv(path: Path) -> list:
    with path.open("r", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def fmt(val: str, decimals: int = 4) -> str:
    try:
        return f"{float(val):.{decimals}f}"
    except (ValueError, TypeError):
        return str(val)


# ── Main ─────────────────────────────────────────────────────────────────────

def main() -> None:
    cfg.REPORT_DIR.mkdir(parents=True, exist_ok=True)

    deep      = json.loads((cfg.RESULTS_DIR / "deep_metrics.json").read_text("utf-8"))
    seq_stats = json.loads((cfg.DATA_PROCESSED_DIR / "sequence_stats.json").read_text("utf-8"))
    base_path = (
        cfg.SUB4_SUMMARY_CSV
        if cfg.SUB4_SUMMARY_CSV.exists()
        else cfg.RESULTS_DIR / "baseline_summary_table_fallback.csv"
    )
    base_rows = read_csv(base_path)

    styles   = getSampleStyleSheet()
    BLUE     = colors.HexColor("#1F4E79")
    MIDBLUE  = colors.HexColor("#2E75B6")
    VLIGHT   = colors.HexColor("#EBF3FB")
    GOLD     = colors.HexColor("#FFF2CC")

    body  = ParagraphStyle("body",  parent=styles["Normal"], fontSize=10,
                           leading=14, spaceAfter=6, alignment=TA_JUSTIFY)
    h1    = ParagraphStyle("h1",    parent=styles["Heading1"], fontSize=14,
                           textColor=BLUE, leading=18, spaceBefore=14, spaceAfter=6)
    h2    = ParagraphStyle("h2",    parent=styles["Heading2"], fontSize=11,
                           textColor=MIDBLUE, leading=14, spaceBefore=10, spaceAfter=4)
    ref   = ParagraphStyle("ref",   parent=body, fontSize=9, leading=13, leftIndent=18)
    ctr   = ParagraphStyle("ctr",   parent=body, alignment=TA_CENTER)
    kw    = ParagraphStyle("kw",    parent=body, fontSize=9, textColor=colors.HexColor("#404040"))

    mean = deep["mean"]
    std  = deep["std"]
    arch = deep["architecture"]
    trn  = deep["training"]
    ev   = deep["evaluation"]

    out_pdf = cfg.REPORT_DIR / "CIS6530_Submission5_Technical_Report.pdf"
    doc = SimpleDocTemplate(str(out_pdf), pagesize=letter,
                            rightMargin=72, leftMargin=72,
                            topMargin=72, bottomMargin=72)
    S = []

    # ── Cover ─────────────────────────────────────────────────────────────────
    S.append(Spacer(1, 0.3*inch))
    S.append(Paragraph(f"{cfg.COURSE_CODE} — {cfg.COURSE_NAME}", ctr))
    S.append(Paragraph("<b>Final Technical Report — Submission 5</b>", ctr))
    S.append(Paragraph("Deep Android Malware Detection on OpCode Sequences", ctr))
    S.append(Spacer(1, 0.2*inch))
    cover = [
        ["Course", f"{cfg.COURSE_CODE} — {cfg.COURSE_NAME}"],
        ["Instructor", "Prof. Ali  /  TA: Miss Iza"],
        ["Term", cfg.TERM_YEAR],
        ["Submission", "Submission 5 — Deep Method"],
        ["Date", cfg.SUBMITTED_DATE],
    ]
    ct = Table(cover, colWidths=[1.8*inch, 4.3*inch])
    ct.setStyle(TableStyle([
        ("GRID",        (0,0),(-1,-1), 0.5, colors.HexColor("#BFBFBF")),
        ("BACKGROUND",  (0,0),(0,-1),  VLIGHT),
        ("FONTSIZE",    (0,0),(-1,-1), 10),
        ("FONTNAME",    (0,0),(0,-1),  "Helvetica-Bold"),
    ]))
    S += [ct, Spacer(1, 0.15*inch)]
    S.append(HRFlowable(width="100%", thickness=1.5, color=MIDBLUE))
    S.append(Spacer(1, 0.1*inch))
    S.append(Paragraph(
        "<b>Keywords:</b> deep learning, CNN, opcode analysis, APT attribution, "
        "malware classification, sequence model, cyber threat intelligence", kw))
    S.append(PageBreak())

    # ── Abstract ──────────────────────────────────────────────────────────────
    S.append(Paragraph("Abstract", h1))
    S.append(HRFlowable(width="100%", thickness=0.5, color=MIDBLUE, spaceAfter=6))
    S.append(Paragraph(
        "This report presents the implementation and evaluation of the deep learning method proposed by "
        "McLaughlin et al. in <i>Deep Android Malware Detection</i> [1], adapted to the multi-class "
        "APT-labelled OpCode dataset assembled in Submissions 2 and 3. The adapted architecture — "
        "Embedding → 1D Convolution → Global Max-Pooling → MLP → Softmax — is trained and evaluated "
        "using 2-fold stratified cross-validation on 59 samples spanning 29 APT classes. "
        f"The model achieves a mean accuracy of {fmt(mean['accuracy'])} and macro-F1 of "
        f"{fmt(mean['macro_f1'])}, which is lower than all Submission 4 classical baselines. "
        "This result is analysed in depth: the gap arises from the fundamental mismatch between the "
        "paper's binary Android application setting and the present multi-class small-sample "
        "APT-attribution regime. The finding is treated as a calibrated negative result — "
        "methodologically valid and analytically informative — and is compared directly against "
        "ten Submission 4 baseline configurations under identical evaluation conditions.",
        body))
    S.append(Spacer(1, 0.1*inch))

    # ── I. Introduction ───────────────────────────────────────────────────────
    S.append(Paragraph("I.  Introduction and Task Definition", h1))
    S.append(HRFlowable(width="100%", thickness=0.5, color=MIDBLUE, spaceAfter=6))
    S.append(Paragraph(
        "Submission 5 requires the implementation of the method proposed in "
        "<i>Deep Android Malware Detection</i> [1] on the OpCode sequences extracted in "
        "Submission 3, followed by a direct comparative evaluation against the classical "
        "baselines reported in Submission 4. The paper proposes a shallow convolutional "
        "neural network that treats Android API call sequences as discrete integer tokens, "
        "embeds them into a dense space, and applies a 1D convolution to capture local "
        "n-gram motifs — followed by global max-pooling, a dense hidden layer, and a "
        "softmax output. The authors evaluate on a binary malware/benign classification "
        "task using a large Android corpus.", body))
    S.append(Paragraph(
        "In this submission, the architecture is faithfully preserved while being adapted "
        "to: (i) OpCode mnemonic sequences rather than API calls, (ii) a 29-class multi-class "
        "APT attribution problem rather than binary detection, and (iii) a highly constrained "
        "dataset of 59 samples. These adaptations are justified and their implications for "
        "expected performance are discussed throughout the report.", body))

    # ── II. Method ────────────────────────────────────────────────────────────
    S.append(Paragraph("II.  Deep Method Implementation", h1))
    S.append(HRFlowable(width="100%", thickness=0.5, color=MIDBLUE, spaceAfter=6))

    S.append(Paragraph("A.  Architecture", h2))
    S.append(Paragraph(
        "The DeepOpcodeCNN follows the paper's selected hyperparameter configuration [1] "
        "exactly. OpCode mnemonic tokens are first encoded as integers via a vocabulary "
        f"of size {seq_stats['vocab_size']} (including PAD=0). The architecture is:", body))
    arch_tbl = [
        ["Layer", "Configuration", "Output Shape"],
        ["Embedding",      f"V={seq_stats['vocab_size']}, dim={arch['embedding_dim']}", "(B, L, 8)"],
        ["Transpose",      "Rearrange for Conv1D",                                       "(B, 8, L)"],
        ["Conv1D + ReLU",  f"{arch['conv_filters']} filters, kernel={arch['kernel_size']}", "(B, 64, L')"],
        ["Global MaxPool", "Max over time dimension",                                     "(B, 64)"],
        ["Dense + ReLU",   f"Units={arch['hidden_units']}",                              "(B, 16)"],
        ["Dense (output)", f"Units=n_classes=29",                                        "(B, 29)"],
    ]
    at = Table(arch_tbl, colWidths=[1.4*inch, 2.8*inch, 1.6*inch])
    at.setStyle(TableStyle([
        ("BACKGROUND",  (0,0),(-1,0), BLUE),
        ("TEXTCOLOR",   (0,0),(-1,0), colors.white),
        ("FONTNAME",    (0,0),(-1,0), "Helvetica-Bold"),
        ("GRID",        (0,0),(-1,-1), 0.5, colors.HexColor("#BFBFBF")),
        ("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.white, VLIGHT]),
        ("FONTSIZE",    (0,0),(-1,-1), 9),
    ]))
    S += [at, Spacer(1, 0.1*inch)]

    S.append(Paragraph("B.  Training Protocol", h2))
    S.append(Paragraph(
        f"Training follows the paper's specified protocol [1]: RMSprop optimiser with "
        f"learning rate {trn['learning_rate']}, {trn['epochs']} epochs, batch size "
        f"{trn['batch_size']}. To address class imbalance — many APT labels have exactly "
        "2 samples — CrossEntropyLoss is weighted by the inverse frequency of each class "
        "in the training fold, normalised so weights sum to n_classes [2].", body))
    S.append(Paragraph(
        f"Evaluation uses StratifiedKFold(n_splits={ev['cv_folds']}, shuffle=True, "
        f"random_state={ev['random_seed']}), matching the Submission 4 protocol exactly "
        "to enable apples-to-apples comparison [3]. All stochastic components are seeded.", body))

    S.append(Paragraph("C.  Sequence Length Adaptation", h2))
    S.append(Paragraph(
        f"OpCode sequences in this dataset range from {seq_stats['min_len']} to "
        f"{seq_stats['max_len']:,} tokens (median: {int(seq_stats['median_len']):,}). "
        f"Padding the full batch to {seq_stats['max_len']:,} tokens would require "
        "approximately 3.2 GB per batch (float32) and causes process termination due to "
        "RAM exhaustion. Sequences are therefore capped at MAX_SEQ_LEN=20,000 tokens. "
        "During training, a random contiguous window is sampled (providing implicit "
        "augmentation); during evaluation, the head window is used (deterministic). "
        "This adaptation preserves the paper's core data flow and is common practice "
        "for long-sequence neural malware models [4].", body))

    # ── III. Data ─────────────────────────────────────────────────────────────
    S.append(Paragraph("III.  Data and Evaluation Protocol", h1))
    S.append(HRFlowable(width="100%", thickness=0.5, color=MIDBLUE, spaceAfter=6))
    S.append(Paragraph(
        "The dataset is inherited from Submissions 2 (APT-labelled malware) and 3 (OpCode "
        "extraction). Three singleton APT labels (G0023_APT16, G0045_menuPass, G0064_APT33) "
        "are excluded because StratifiedKFold requires at least 2 samples per class [3]. "
        f"The retained dataset contains {seq_stats['n_samples']} samples across "
        f"{seq_stats['n_classes']} APT classes with vocabulary size "
        f"{seq_stats['vocab_size']}. Label semantics follow MITRE ATT&CK group identifiers [5], [6].", body))
    S.append(Paragraph(
        "All five rubric-required metrics are reported: Accuracy, Macro-Precision, "
        "Macro-Recall, Macro-F1, and the aggregated Confusion Matrix. Macro averaging "
        "is prioritised because it treats each class equally regardless of support [3], "
        "which is essential in a 29-class setting where rare labels are analytically "
        "important for CTI triage workflows [5].", body))

    # ── IV. Results ───────────────────────────────────────────────────────────
    S.append(Paragraph("IV.  Results — DeepOpcodeCNN", h1))
    S.append(HRFlowable(width="100%", thickness=0.5, color=MIDBLUE, spaceAfter=6))
    fold_data = [["Fold", "Accuracy", "Macro-Precision", "Macro-Recall", "Macro-F1", "n_test"]]
    for fd in deep["folds"]:
        fold_data.append([
            str(fd["fold"]),
            fmt(fd["accuracy"]),
            fmt(fd["macro_precision"]),
            fmt(fd["macro_recall"]),
            fmt(fd["macro_f1"]),
            str(fd["n_test"]),
        ])
    fold_data.append([
        "Mean",
        fmt(mean["accuracy"]),
        fmt(mean["macro_precision"]),
        fmt(mean["macro_recall"]),
        fmt(mean["macro_f1"]),
        "—",
    ])
    ft = Table(fold_data, colWidths=[0.5*inch,1.0*inch,1.3*inch,1.1*inch,1.0*inch,0.7*inch])
    ft.setStyle(TableStyle([
        ("BACKGROUND",  (0,0),(-1,0),  BLUE),
        ("TEXTCOLOR",   (0,0),(-1,0),  colors.white),
        ("FONTNAME",    (0,0),(-1,0),  "Helvetica-Bold"),
        ("BACKGROUND",  (0,-1),(-1,-1),GOLD),
        ("FONTNAME",    (0,-1),(-1,-1),"Helvetica-Bold"),
        ("GRID",        (0,0),(-1,-1), 0.5, colors.HexColor("#BFBFBF")),
        ("ROWBACKGROUNDS",(0,1),(-1,-2),[colors.white, VLIGHT]),
        ("FONTSIZE",    (0,0),(-1,-1), 9),
        ("ALIGN",       (1,0),(-1,-1), "CENTER"),
    ]))
    S.append(Paragraph("Table 1. DeepOpcodeCNN per-fold and mean performance (2-fold CV).", ctr))
    S += [Spacer(1,0.05*inch), ft, Spacer(1,0.1*inch)]
    S.append(Paragraph(
        f"The model achieves mean accuracy {fmt(mean['accuracy'])} (±{fmt(std['accuracy'])}) "
        f"and macro-F1 {fmt(mean['macro_f1'])}. Fold 1 outperforms Fold 2 substantially "
        "(accuracy 0.0667 vs 0.0345), indicating high variance consistent with the "
        "very limited per-class training support (approximately 1–2 samples per class "
        "per training fold). The confusion matrix (Appendix A) shows the model largely "
        "predicts one or two dominant classes, failing to discriminate most APT groups.", body))

    # ── V. Comparison ─────────────────────────────────────────────────────────
    S.append(Paragraph("V.  Comparative Analysis vs. Submission 4 Baselines", h1))
    S.append(HRFlowable(width="100%", thickness=0.5, color=MIDBLUE, spaceAfter=6))

    cmp_hdr = ["Family","Features","Model","Accuracy","Macro-F1"]
    cmp_rows = [cmp_hdr]
    for r in base_rows:
        cmp_rows.append([
            r.get("family","Baseline (Sub 4)").replace("Baseline (Submission 4)","Sub 4 Baseline"),
            r.get("features",""),
            r.get("model",""),
            fmt(r.get("mean_accuracy","")),
            fmt(r.get("mean_macro_f1","")),
        ])
    cmp_rows.append([
        "Sub 5 — Deep",
        "seq (embed+CNN)",
        "DeepOpcodeCNN",
        fmt(mean["accuracy"]),
        fmt(mean["macro_f1"]),
    ])
    cws = [1.1*inch, 0.8*inch, 1.3*inch, 0.9*inch, 0.9*inch]
    cmt = Table(cmp_rows, colWidths=cws)
    n   = len(cmp_rows)
    cmt.setStyle(TableStyle([
        ("BACKGROUND",     (0,0),(-1,0),   BLUE),
        ("TEXTCOLOR",      (0,0),(-1,0),   colors.white),
        ("FONTNAME",       (0,0),(-1,0),   "Helvetica-Bold"),
        ("BACKGROUND",     (0,n-1),(-1,n-1), colors.HexColor("#FCE4D6")),
        ("GRID",           (0,0),(-1,-1),  0.5, colors.HexColor("#BFBFBF")),
        ("ROWBACKGROUNDS", (0,1),(-1,-2),  [colors.white, VLIGHT]),
        ("FONTSIZE",       (0,0),(-1,-1),  8.5),
        ("ALIGN",          (3,0),(-1,-1),  "CENTER"),
    ]))
    S.append(Paragraph(
        "Table 2. Apples-to-apples comparison — identical dataset (59 samples, 29 classes), "
        "identical StratifiedKFold(n_splits=2, random_state=42), identical macro-F1 metric. "
        "KNN evaluated at k=3 (best), k=4, k=5 per Submission 4 rubric.", ctr))
    S += [Spacer(1,0.05*inch), cmt, Spacer(1,0.1*inch)]

    S.append(Paragraph(
        "The DeepOpcodeCNN underperforms all ten Submission 4 baseline configurations. "
        "The best classical result is LinearSVC with 2-gram features (accuracy 0.2546, "
        "macro-F1 0.1775), which is approximately 5× better in accuracy and 25× better "
        "in macro-F1 than the deep model. Among KNN configurations, k=3 is the best "
        "classical KNN (accuracy 0.1011, macro-F1 0.0601), still substantially outperforming "
        "the CNN. The gap is not a failure of implementation but a systematic consequence "
        "of the setting described in the following section.", body))

    # ── VI. Interpretation ────────────────────────────────────────────────────
    S.append(Paragraph("VI.  Interpretation and Analysis", h1))
    S.append(HRFlowable(width="100%", thickness=0.5, color=MIDBLUE, spaceAfter=6))

    S.append(Paragraph("A.  Why the Deep Model Underperforms the Classical Baselines", h2))
    S.append(Paragraph(
        "The paper's method was designed for binary malware detection on Android datasets "
        "containing thousands of samples per class [1]. The present setting differs "
        "fundamentally in three ways that together explain the performance gap:", body))
    reasons = [
        ["1. Sample scarcity",
         "59 samples across 29 classes means approximately 1 training sample per class "
         "per fold. Neural networks require many gradient updates to fit meaningful "
         "representations; with 1 training example per class, the embedding and conv "
         "weights cannot generalise [7]."],
        ["2. High class cardinality",
         "The paper reports binary classification. A 29-class problem with macro-F1 "
         "evaluation penalises every class equally. The CNN predicts 1–2 dominant "
         "classes and fails most others, collapsing macro-F1 to near zero."],
        ["3. n-gram sparsity advantage",
         "LinearSVC on 2-gram features has an inductive bias well-suited to this regime: "
         "it aggregates a sparse 10,063-dimensional feature vector using a global linear "
         "decision boundary. This requires far fewer effective parameters than learning "
         "meaningful embeddings from scratch [8]."],
    ]
    rt = Table(reasons, colWidths=[1.3*inch, 4.5*inch])
    rt.setStyle(TableStyle([
        ("FONTNAME", (0,0),(0,-1), "Helvetica-Bold"),
        ("FONTSIZE", (0,0),(-1,-1), 9),
        ("VALIGN",   (0,0),(-1,-1), "TOP"),
        ("GRID",     (0,0),(-1,-1), 0.3, colors.HexColor("#DDDDDD")),
        ("ROWBACKGROUNDS",(0,0),(-1,-1),[colors.white, VLIGHT]),
    ]))
    S += [rt, Spacer(1,0.1*inch)]

    S.append(Paragraph("B.  When Would the Deep Method Be Expected to Excel?", h2))
    S.append(Paragraph(
        "The paper's method is expected to outperform n-gram baselines when: "
        "(i) the dataset is large enough to train meaningful token embeddings "
        "(hundreds of examples per class); (ii) local instruction motifs are "
        "discriminative and not captured well by simple bigram counts; and (iii) "
        "the sequence structure itself (beyond frequency) encodes class identity. "
        "In a well-resourced malware corpus, the convolutional architecture's ability "
        "to detect positional n-gram patterns regardless of absolute frequency may "
        "provide a genuine advantage over bag-of-ngrams representations [1], [4], [9].", body))

    S.append(Paragraph("C.  CTI Implications", h2))
    S.append(Paragraph(
        "For operational CTI triage, the LinearSVC 2-gram baseline remains the "
        "recommended model for this dataset. The deep method should be re-evaluated "
        "once the dataset reaches sufficient scale (≥ 50 samples per APT class). "
        "The confusion matrix (Appendix A) shows the CNN collapses predictions onto "
        "a small number of high-frequency classes — a known failure mode of neural "
        "classifiers under severe class imbalance with insufficient data [2], [7].", body))

    # ── VII. Limitations ──────────────────────────────────────────────────────
    S.append(Paragraph("VII.  Limitations and Threats to Validity", h1))
    S.append(HRFlowable(width="100%", thickness=0.5, color=MIDBLUE, spaceAfter=6))
    lims = [
        "1. Severe per-class sample scarcity (≈1 training sample/class/fold) limits all models.",
        "2. Sequence truncation to 20,000 tokens may discard discriminative instruction patterns "
          "present in the tail of long sequences.",
        "3. Random window sampling during training introduces fold-level variance; the reported "
          "std (±0.0161) is an underestimate of true generalisation variance.",
        "4. Label taxonomy reflects public ATT&CK reporting conventions — not independently "
          "verified actor ground truth [5], [6].",
        "5. Only 10 training epochs are used per the paper's protocol; more epochs may improve "
          "the deep model's performance but risk overfitting on this small dataset.",
        "6. No hyperparameter search was performed (lr, embed_dim, kernel_size) to preserve "
          "fidelity to the paper and avoid overfitting on the validation set.",
    ]
    for lim in lims:
        S.append(Paragraph(f"• {lim}", body))
    S.append(Spacer(1, 0.1*inch))

    # ── VIII. Reproducibility ─────────────────────────────────────────────────
    S.append(Paragraph("VIII.  Reproducibility", h1))
    S.append(HRFlowable(width="100%", thickness=0.5, color=MIDBLUE, spaceAfter=6))
    repro = [
        ["Parameter",              "Value"],
        ["Random seed",            str(ev["random_seed"])],
        ["CV strategy",            f"StratifiedKFold(n_splits={ev['cv_folds']}, shuffle=True)"],
        ["Optimizer",              f"RMSprop lr={trn['learning_rate']}"],
        ["Epochs",                 str(trn["epochs"])],
        ["Batch size",             str(trn["batch_size"])],
        ["MAX_SEQ_LEN",            str(trn["max_seq_len"])],
        ["Class weighting",        "Inverse-frequency on training fold"],
        ["Device",                 "CUDA if available, else CPU"],
        ["Submission 4 protocol",  "StratifiedKFold(n_splits=2, random_state=42) — identical"],
    ]
    rt2 = Table(repro, colWidths=[2.0*inch, 4.0*inch])
    rt2.setStyle(TableStyle([
        ("BACKGROUND",  (0,0),(-1,0), BLUE),
        ("TEXTCOLOR",   (0,0),(-1,0), colors.white),
        ("FONTNAME",    (0,0),(-1,0), "Helvetica-Bold"),
        ("GRID",        (0,0),(-1,-1), 0.5, colors.HexColor("#BFBFBF")),
        ("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.white, VLIGHT]),
        ("FONTSIZE",    (0,0),(-1,-1), 9),
    ]))
    S += [rt2, Spacer(1, 0.1*inch)]
    cmds = [
        "python3 -m scripts.01_build_manifest",
        "python3 -m scripts.02_preprocess_sequences",
        "python3 -m scripts.03_train_eval_deep_model_cv",
        "python3 -m scripts.04_plot_confusion",
        "python3 -m scripts.05_compare_to_baselines",
        "python3 -m scripts.06_generate_report_pdf",
        "python3 -m scripts.07_make_final_zip",
    ]
    for cmd in cmds:
        S.append(Paragraph(f"<font name='Courier' size='9'>{cmd}</font>", body))

    # ── IX. Conclusion ────────────────────────────────────────────────────────
    S.append(Paragraph("IX.  Conclusion", h1))
    S.append(HRFlowable(width="100%", thickness=0.5, color=MIDBLUE, spaceAfter=6))
    S.append(Paragraph(
        "This report implements and evaluates the deep learning method from McLaughlin "
        "et al. [1] on APT-labelled OpCode sequences under identical evaluation conditions "
        "to the Submission 4 classical baselines. The DeepOpcodeCNN achieves mean accuracy "
        f"{fmt(mean['accuracy'])} and macro-F1 {fmt(mean['macro_f1'])}, below all ten "
        "classical baseline configurations. This outcome is a calibrated negative result: "
        "it is methodologically valid and provides direct evidence that the paper's method, "
        "originally designed for large-scale binary Android detection, does not transfer to "
        "the present 29-class small-sample APT attribution regime without additional data. "
        "LinearSVC with 2-gram features remains the recommended baseline for this dataset. "
        "The deep method should be revisited once per-class sample counts reach a level "
        "sufficient to train meaningful token embeddings.", body))
    S.append(PageBreak())

    # ── References ────────────────────────────────────────────────────────────
    S.append(Paragraph("References", h1))
    S.append(HRFlowable(width="100%", thickness=0.5, color=MIDBLUE, spaceAfter=6))
    references = [
        "[1] N. McLaughlin, J. Martinez del Rincon, B. Kang, S. Yerima, P. Miller, "
        "S. Sezer, Y. Safaei, E. Trickel, Z. Zhao, A. Doupé, and G.-J. Ahn, "
        "\"Deep Android Malware Detection,\" in <i>Proc. 7th ACM Conf. Data and "
        "Application Security and Privacy (CODASPY)</i>, Scottsdale, AZ, USA, 2017, "
        "pp. 301–308. doi: 10.1145/3029806.3029823",

        "[2] F. Pedregosa, G. Varoquaux, A. Gramfort, V. Michel, B. Thirion, O. Grisel, "
        "M. Blondel, P. Prettenhofer, R. Weiss, V. Dubourg, J. Vanderplas, A. Passos, "
        "D. Cournapeau, M. Brucher, M. Perrot, and E. Duchesnay, \"Scikit-learn: Machine "
        "Learning in Python,\" <i>J. Mach. Learn. Res.</i>, vol. 12, pp. 2825–2830, 2011. "
        "[Online]. Available: https://jmlr.org/papers/v12/pedregosa11a.html",

        "[3] Scikit-learn Developers, \"StratifiedKFold,\" 2026. [Online]. Available: "
        "https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.StratifiedKFold.html",

        "[4] I. Santos, F. Brezo, X. Ugarte-Pedrero, and P. G. Bringas, \"Opcode sequences "
        "as representation of executables for data-mining-based unknown malware detection,\" "
        "<i>Inf. Sci.</i>, vol. 231, pp. 64–82, 2013. "
        "doi: 10.1016/j.ins.2011.08.020",

        "[5] MITRE, \"MITRE ATT&CK,\" 2026. [Online]. Available: https://attack.mitre.org/",

        "[6] MITRE, \"Groups | MITRE ATT&CK,\" 2026. [Online]. Available: "
        "https://attack.mitre.org/groups/",

        "[7] Y. LeCun, Y. Bengio, and G. Hinton, \"Deep learning,\" "
        "<i>Nature</i>, vol. 521, no. 7553, pp. 436–444, 2015. "
        "doi: 10.1038/nature14539",

        "[8] J. Z. Kolter and M. A. Maloof, \"Learning to Detect and Classify Malicious "
        "Executables in the Wild,\" <i>J. Mach. Learn. Res.</i>, vol. 7, "
        "pp. 2721–2744, 2006. [Online]. Available: https://www.jmlr.org/papers/v7/kolter06a.html",

        "[9] Y. Kim, \"Convolutional Neural Networks for Sentence Classification,\" in "
        "<i>Proc. 2014 Conf. Empirical Methods in Natural Language Processing (EMNLP)</i>, "
        "Doha, Qatar, 2014, pp. 1746–1751. doi: 10.3115/v1/D14-1181",

        "[10] A. Paszke, S. Gross, F. Massa, A. Lerer, J. Bradbury, G. Chanan, "
        "T. Killeen, Z. Lin, N. Gimelshein, L. Antiga, A. Desmaison, A. Köpf, "
        "E. Yang, Z. DeVito, M. Raison, A. Tejani, S. Chilamkurthy, B. Steiner, "
        "L. Fang, J. Bai, and S. Chintala, \"PyTorch: An Imperative Style, "
        "High-Performance Deep Learning Library,\" in <i>Advances in Neural Information "
        "Processing Systems (NeurIPS)</i>, vol. 32, 2019.",

        "[11] National Security Agency, \"Ghidra: A Software Reverse Engineering (SRE) "
        "Framework,\" GitHub, 2026. [Online]. Available: "
        "https://github.com/NationalSecurityAgency/ghidra",

        "[12] Y. Ye, D. Wang, T. Li, and D. Ye, \"A Survey on Malware Detection Using "
        "Data Mining Techniques,\" <i>ACM Comput. Surv.</i>, vol. 50, no. 3, Art. 41, "
        "2017. doi: 10.1145/3073559",
    ]
    for r in references:
        S.append(Paragraph(r, ref))
        S.append(Spacer(1, 0.05*inch))

    S.append(PageBreak())

    # ── Appendix A ────────────────────────────────────────────────────────────
    S.append(Paragraph("Appendix A — DeepOpcodeCNN Confusion Matrix", h1))
    S.append(Paragraph(
        "The confusion matrix below is aggregated over both stratified folds. "
        "The model predominantly predicts a single dominant class, confirming the "
        "collapse behaviour discussed in Section VI-C.", body))
    S.append(Spacer(1, 0.1*inch))
    conf_img_path = cfg.RESULTS_DIR / "confusion_DeepOpcodeCNN.png"
    if conf_img_path.exists():
        from reportlab.platypus import Image as RLImage
        S.append(RLImage(str(conf_img_path), width=6.0*inch, height=4.5*inch))
        S.append(Paragraph(
            "Fig. A1. Aggregated confusion matrix — DeepOpcodeCNN "
            "(2-fold Stratified CV, 29 classes, 59 samples).", ctr))

    doc.build(S)
    print(f"[+] Wrote {out_pdf}")


if __name__ == "__main__":
    main()
