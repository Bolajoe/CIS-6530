"""
config.py — Centralised configuration for CIS 6530 Submission 5
================================================================
Deep Android Malware Detection adapted to OpCode sequences.

Course    : CIS 6530 — Cybersecurity and Threat Intelligence
Submission: 5 — Deep Method (CNN on OpCode sequences)
Date      : March 2026
"""

from pathlib import Path

# ---------------------------------------------------------------------------
# USER PATHS — UPDATE THESE TO MATCH YOUR ENVIRONMENT
# ---------------------------------------------------------------------------
SUB3_OUTPUT = Path(r"/home/kali/Desktop/SUBMISSION_3_OUTPUT")
SUB2_ROOT   = Path(r"/home/kali/Desktop/cis6530 folder/CIS_6530_Assignment_Submission_2")

# Path to Submission 4 summary table (used for apples-to-apples baseline comparison).
# If this path does not exist, the fallback CSV in results/ is used automatically.
SUB4_SUMMARY_CSV = Path(r"/home/kali/Desktop/Submission_4_CV/results/summary_table.csv")

# ---------------------------------------------------------------------------
# DERIVED LOCATIONS
# ---------------------------------------------------------------------------
SUB3_RAW_OPCODES: Path = SUB3_OUTPUT / "Raw_Extracted_Files"
SUB2_EXEC_ROOT:   Path = SUB2_ROOT   / "Executable_Malware"

# ---------------------------------------------------------------------------
# LOCAL PROJECT PATHS
# ---------------------------------------------------------------------------
PROJECT_ROOT:       Path = Path(__file__).resolve().parents[1]
DATA_PROCESSED_DIR: Path = PROJECT_ROOT / "data_processed"
RESULTS_DIR:        Path = PROJECT_ROOT / "results"
REPORT_DIR:         Path = PROJECT_ROOT / "report"

# ---------------------------------------------------------------------------
# EXPERIMENT CONFIGURATION
# ---------------------------------------------------------------------------
RANDOM_SEED: int = 42
N_SPLITS:    int = 2   # 2-fold StratifiedKFold (matches Submission 4 protocol)

# ---------------------------------------------------------------------------
# DEEP ANDROID MALWARE DETECTION — PAPER HYPERPARAMETERS (McLaughlin et al.)
# ---------------------------------------------------------------------------
EMBED_DIM:      int   = 8      # Embedding dimension (paper: 8)
N_FILTERS:      int   = 64     # Conv1D filters (paper: 64)
KERNEL_SIZE:    int   = 8      # Convolution kernel length (paper: 8)
HIDDEN_UNITS:   int   = 16     # Dense hidden layer size (paper: 16)
BATCH_SIZE:     int   = 16     # Mini-batch size (paper: 16)
EPOCHS:         int   = 10     # Training epochs (paper: 10)
LEARNING_RATE:  float = 1e-2   # RMSProp learning rate (paper: 1e-2)
OPTIMIZER:      str   = "RMSprop"

# ---------------------------------------------------------------------------
# SEQUENCE LENGTH ADAPTATION
# ---------------------------------------------------------------------------
# OpCode sequences can reach ~500,000 tokens. Padding to this length exhausts
# RAM and causes process termination. Sequences are capped at MAX_SEQ_LEN.
#   Train : random contiguous window  (introduces augmentation)
#   Eval  : head window (deterministic, reproducible)
# Reduce to 10,000 if RAM is limited (< 8 GB).
MAX_SEQ_LEN: int = 20000

# ---------------------------------------------------------------------------
# SUBMISSION 4 BASELINE REFERENCE (for apples-to-apples comparison)
# ---------------------------------------------------------------------------
# KNN rubric specifies k in {3, 4, 5}. k=3 is the best-performing KNN.
# All three k values are included in the comparison table.
KNN_K_VALUES: list = [3, 4, 5]   # all evaluated in Submission 4
KNN_K_BEST:   int  = 3           # best-performing KNN (primary reference)

# ---------------------------------------------------------------------------
# REPORT IDENTITY
# ---------------------------------------------------------------------------
STUDENT_NAME:  str = "Group"
STUDENT_ID:    str = ""
COURSE_NAME:   str = "Cybersecurity and Threat Intelligence"
COURSE_CODE:   str = "CIS 6530"
TERM_YEAR:     str = "Winter 2026"
SUBMISSION:    str = "Submission 5 — Deep Method (Deep Android Malware Detection on OpCodes)"
DUE_DATE:      str = "March 2026"
SUBMITTED_DATE:str = "March 2026"
