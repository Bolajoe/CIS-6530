#!/usr/bin/env python3
"""
05_compare_to_baselines.py — Build the unified comparison table
================================================================
Merges Submission 4 baseline results (LinearSVC, KNN k=3/4/5, Decision Tree
on 1-gram and 2-gram features) with the DeepOpcodeCNN result into a single
CSV comparison table used by the report generator.

Baseline source priority
------------------------
1. cfg.SUB4_SUMMARY_CSV  — Submission 4 results file (if present)
2. results/baseline_summary_table_fallback.csv — bundled fallback (all k values)

Output
------
    results/comparison_table.csv

Usage
-----
    python3 -m scripts.05_compare_to_baselines   (run after 03)

Course    : CIS 6530 — Cybersecurity and Threat Intelligence
Submission: 5 — Deep Method
"""

import csv
from pathlib import Path

from scripts import config as cfg


def read_csv(path: Path) -> list:
    with path.open("r", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def main() -> None:
    deep_path = cfg.RESULTS_DIR / "deep_summary_row.csv"
    if not deep_path.exists():
        raise FileNotFoundError(
            "Missing deep_summary_row.csv. Run: python3 -m scripts.03_train_eval_deep_model_cv"
        )

    # Choose baseline source
    base_path = (
        cfg.SUB4_SUMMARY_CSV
        if cfg.SUB4_SUMMARY_CSV.exists()
        else cfg.RESULTS_DIR / "baseline_summary_table_fallback.csv"
    )
    print(f"[+] Baseline source: {base_path}")

    base_rows = read_csv(base_path)
    deep_rows = read_csv(deep_path)

    out = cfg.RESULTS_DIR / "comparison_table.csv"
    fields = [
        "family", "features", "model",
        "mean_accuracy", "std_accuracy",
        "mean_macro_precision", "mean_macro_recall", "mean_macro_f1",
    ]
    with out.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for r in base_rows:
            w.writerow({
                "family":              r.get("family", "Baseline (Submission 4)"),
                "features":            r.get("features", ""),
                "model":               r.get("model", ""),
                "mean_accuracy":       r.get("mean_accuracy", ""),
                "std_accuracy":        r.get("std_accuracy", ""),
                "mean_macro_precision":r.get("mean_macro_precision", ""),
                "mean_macro_recall":   r.get("mean_macro_recall", ""),
                "mean_macro_f1":       r.get("mean_macro_f1", ""),
            })
        for r in deep_rows:
            w.writerow({
                "family":              "Deep method (Submission 5)",
                "features":            "sequence (embedding+CNN)",
                "model":               r.get("model", "DeepOpcodeCNN"),
                "mean_accuracy":       r.get("mean_accuracy", ""),
                "std_accuracy":        r.get("std_accuracy", ""),
                "mean_macro_precision":r.get("mean_macro_precision", ""),
                "mean_macro_recall":   r.get("mean_macro_recall", ""),
                "mean_macro_f1":       r.get("mean_macro_f1", ""),
            })

    print(f"[+] Wrote {out}")


if __name__ == "__main__":
    main()
