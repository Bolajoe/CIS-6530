#!/usr/bin/env python3
"""
04_plot_confusion.py — Plot the aggregated DeepOpcodeCNN confusion matrix
=========================================================================
Reads the summed confusion matrix from deep_metrics.json and saves a
publication-quality PNG.

Output
------
    results/confusion_DeepOpcodeCNN.png

Usage
-----
    python3 -m scripts.04_plot_confusion   (run after 03)

Course    : CIS 6530 — Cybersecurity and Threat Intelligence
Submission: 5 — Deep Method
"""

import json
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import ConfusionMatrixDisplay

from scripts import config as cfg


def main() -> None:
    deep      = json.loads((cfg.RESULTS_DIR / "deep_metrics.json").read_text(encoding="utf-8"))
    label_map = json.loads((cfg.DATA_PROCESSED_DIR / "label_encoder.json").read_text(encoding="utf-8"))
    labels    = [label_map[str(i)] for i in range(len(label_map))]

    cm = np.array(deep["confusion_matrix_sum"])

    plt.rcParams.update({"font.family": "serif", "font.size": 8})
    fig, ax = plt.subplots(figsize=(12, 9))
    disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=labels)
    disp.plot(ax=ax, xticks_rotation=90, values_format="d", colorbar=True)
    ax.set_title(
        "DeepOpcodeCNN — Aggregated Confusion Matrix\n"
        f"(2-fold Stratified CV, {deep['data']['n_classes']} classes, "
        f"{deep['data']['n_samples']} samples)",
        pad=14, fontsize=11,
    )
    fig.tight_layout()

    out = cfg.RESULTS_DIR / "confusion_DeepOpcodeCNN.png"
    fig.savefig(out, dpi=200, bbox_inches="tight")
    plt.close(fig)
    print(f"[+] Wrote {out}")


if __name__ == "__main__":
    main()
