#!/usr/bin/env bash
set -e

python -m scripts.01_build_manifest
python -m scripts.02_preprocess_sequences
python -m scripts.03_train_eval_deep_model_cv
python -m scripts.04_plot_confusion
python -m scripts.05_compare_to_baselines
python -m scripts.06_generate_report_pdf
python -m scripts.07_make_final_zip
python -m scripts.08_plot_training_curves