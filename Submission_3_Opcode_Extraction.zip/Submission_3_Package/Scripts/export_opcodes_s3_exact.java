// export_opcodes_s3_exact.java  (Ghidra Java Script - headless safe)
// Usage (headless):
//   -postScript export_opcodes_s3_exact.java <OUTPUT_DIR> <OUTPUT_NAME_STEM>
//
// Writes:
//   <OUTPUT_DIR>/Raw_Extracted_Files/<OUTPUT_NAME_STEM>.opcode   (mnemonics only)
//   <OUTPUT_DIR>/logs/<OUTPUT_NAME_STEM>.log
//   <OUTPUT_DIR>/metadata/<OUTPUT_NAME_STEM>.json
//   <OUTPUT_DIR>/summary/<OUTPUT_NAME_STEM>.json

import ghidra.app.script.GhidraScript;
import ghidra.program.model.listing.*;
import ghidra.program.model.address.Address;
import ghidra.program.model.lang.Language;
import ghidra.program.model.lang.CompilerSpec;

import java.io.*;

public class export_opcodes_s3_exact extends GhidraScript {

    private static final int MAX_INSTRUCTIONS_PER_FUNCTION = 20000;
    private static final long MAX_TOTAL_INSTRUCTIONS = 500000L;

    @Override
    public void run() throws Exception {

        String[] args = getScriptArgs();
        if (args.length < 2) {
            printerr("Usage: -postScript export_opcodes_s3_exact.java <OUTPUT_DIR> <OUTPUT_NAME_STEM>");
            return;
        }

        File outBase = new File(args[0]);
        String nameStem = sanitizeStem(args[1]);

        File rawDir = new File(outBase, "Raw_Extracted_Files");
        File logsDir = new File(outBase, "logs");
        File metaDir = new File(outBase, "metadata");
        File summDir = new File(outBase, "summary");

        rawDir.mkdirs(); logsDir.mkdirs(); metaDir.mkdirs(); summDir.mkdirs();

        File opcodeFile = new File(rawDir, nameStem + ".opcode");
        File logFile = new File(logsDir, nameStem + ".log");
        File metaFile = new File(metaDir, nameStem + ".json");
        File summFile = new File(summDir, nameStem + ".json");

        Listing listing = currentProgram.getListing();
        FunctionManager fm = currentProgram.getFunctionManager();
        FunctionIterator funcs = fm.getFunctions(true);

        Language lang = currentProgram.getLanguage();
        CompilerSpec cs = currentProgram.getCompilerSpec();

        String arch = lang.getProcessor().toString();
        String endian = lang.isBigEndian() ? "big" : "little";
        String languageID = lang.getLanguageID().toString();
        String compilerID = cs.getCompilerSpecID().toString();
        String programName = currentProgram.getName();

        // metadata.json (manual JSON, no external libs)
        try (PrintWriter mw = new PrintWriter(new BufferedWriter(new FileWriter(metaFile)))) {
            mw.println("{");
            mw.println("  \"submission2_name_stem\": \"" + esc(nameStem) + "\",");
            mw.println("  \"program_name\": \"" + esc(programName) + "\",");
            mw.println("  \"architecture\": \"" + esc(arch) + "\",");
            mw.println("  \"endianness\": \"" + esc(endian) + "\",");
            mw.println("  \"language_id\": \"" + esc(languageID) + "\",");
            mw.println("  \"compiler_spec\": \"" + esc(compilerID) + "\",");
            mw.println("  \"format\": \"MNEMONICS_ONLY_WITH_FUNCTION_MARKERS\",");
            mw.println("  \"caps\": {\"per_function\": " + MAX_INSTRUCTIONS_PER_FUNCTION + ", \"total\": " + MAX_TOTAL_INSTRUCTIONS + "}");
            mw.println("}");
        }

        long totalInstructions = 0;
        int totalFunctions = 0;
        int skipped = 0;
        int truncated = 0;

        try (PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(opcodeFile)));
             PrintWriter lw  = new PrintWriter(new BufferedWriter(new FileWriter(logFile)))) {

            out.println("# submission2_name_stem=" + nameStem);
            out.println("# program_name=" + programName);
            out.println("# architecture=" + arch);
            out.println("# endianness=" + endian);
            out.println("# language_id=" + languageID);
            out.println("# compiler_spec=" + compilerID);
            out.println("# format=MNEMONICS_ONLY_WITH_FUNCTION_MARKERS");
            out.println("# caps: per_function=" + MAX_INSTRUCTIONS_PER_FUNCTION + ", total=" + MAX_TOTAL_INSTRUCTIONS);
            out.println();

            while (funcs.hasNext() && !monitor.isCancelled()) {

                Function func = funcs.next();
                totalFunctions++;

                String funcName = sanitizeStem(func.getName());
                Address entry = func.getEntryPoint();

                InstructionIterator it = listing.getInstructions(func.getBody(), true);

                int count = 0;
                boolean funcTrunc = false;

                out.println("<FUNCTION> " + funcName + " " + entry);

                while (it.hasNext()) {
                    if (count >= MAX_INSTRUCTIONS_PER_FUNCTION) { funcTrunc = true; break; }
                    if (totalInstructions >= MAX_TOTAL_INSTRUCTIONS) {
                        lw.println("STOP: Hit MAX_TOTAL_INSTRUCTIONS at " + funcName);
                        break;
                    }

                    Instruction instr = it.next();
                    out.println(instr.getMnemonicString());

                    count++;
                    totalInstructions++;
                }

                out.println();

                if (count == 0) skipped++;
                if (funcTrunc) {
                    truncated++;
                    lw.println("Truncated: " + funcName + " at " + MAX_INSTRUCTIONS_PER_FUNCTION);
                } else {
                    lw.println("Processed: " + funcName + " | Instructions: " + count);
                }

                if (totalInstructions >= MAX_TOTAL_INSTRUCTIONS) break;
            }

            lw.println("Total Functions: " + totalFunctions);
            lw.println("Total Instructions: " + totalInstructions);
            lw.println("Output: " + opcodeFile.getAbsolutePath());
        }

        // summary.json
        try (PrintWriter sw = new PrintWriter(new BufferedWriter(new FileWriter(summFile)))) {
            sw.println("{");
            sw.println("  \"submission2_name_stem\": \"" + esc(nameStem) + "\",");
            sw.println("  \"total_functions\": " + totalFunctions + ",");
            sw.println("  \"skipped_zero_instr\": " + skipped + ",");
            sw.println("  \"truncated_functions\": " + truncated + ",");
            sw.println("  \"total_instructions\": " + totalInstructions + ",");
            sw.println("  \"opcode_file\": \"Raw_Extracted_Files/" + esc(nameStem) + ".opcode\"");
            sw.println("}");
        }
    }

    private String sanitizeStem(String s) {
        if (s == null) return "unknown";
        return s.replaceAll("[^a-zA-Z0-9_\\-\\.]", "_");
    }

    private String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
