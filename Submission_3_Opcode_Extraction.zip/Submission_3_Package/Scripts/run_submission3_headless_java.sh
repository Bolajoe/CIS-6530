#!/usr/bin/env bash
set -euo pipefail

ANALYZE="/home/kali/Downloads/ghidra_12.0.3_PUBLIC/support/analyzeHeadless"
SCRIPTS="/home/kali/ghidra_scripts"

IN_DIR="$HOME/Desktop/cis6530 folder/CIS_6530_Assignment_Submission_2/Executable_Malware"
OUT_DIR="$HOME/Desktop/SUBMISSION_3_OUTPUT"
PROJ_DIR="/tmp/ghidra_s3_proj_java"

mkdir -p "$OUT_DIR" "$PROJ_DIR"

mapfile -t FILES < <(
  find "$IN_DIR" -type f \( -iname "*.exe" -o -iname "*.dll" -o -iname "*.elf" \) 2>/dev/null
)

echo "[*] Found ${#FILES[@]} executables."

FAILS=0
for f in "${FILES[@]}"; do
  bn="$(basename "$f")"
  stem="${bn%.*}"

  echo "[*] Processing: $bn"

  "$ANALYZE" "$PROJ_DIR" "S3Proj" \
    -import "$f" \
    -analysisTimeoutPerFile 600 \
    -postScript export_opcodes_s3_exact.java "$OUT_DIR" "$stem" \
    -scriptPath "$SCRIPTS" \
    -deleteProject \
    || { echo "[!] FAILED: $bn"; FAILS=$((FAILS+1)); }
done

echo "[+] DONE. Failures: $FAILS"
echo "Opcodes in: $OUT_DIR/Raw_Extracted_Files"
