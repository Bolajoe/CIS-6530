#!/usr/bin/env python3
"""
Plot aggregated confusion matrices (sum over folds) for each model and feature set.
"""
import json
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import ConfusionMatrixDisplay
from scripts import config as cfg

def load_labels():
    label_map = json.loads((cfg.DATA_PROCESSED_DIR / "label_encoder.json").read_text(encoding="utf-8"))
    return [label_map[str(i)] for i in range(len(label_map))]

def plot_one(metrics_path, labels):
    obj = json.loads(metrics_path.read_text(encoding="utf-8"))
    for m in obj["models"]:
        cm = np.array(m["confusion_matrix_sum"])
        disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=labels)
        fig, ax = plt.subplots(figsize=(10, 8))
        disp.plot(ax=ax, xticks_rotation=90, values_format="d")
        ax.set_title(f"{m['model']} — {obj['feature_set']} (sum over {obj['cv']['n_splits']} folds)")
        fig.tight_layout()
        safe = m["model"].replace("/", "_")
        out = cfg.RESULTS_DIR / f"confusion_{safe}_{obj['feature_set']}.png"
        fig.savefig(out, dpi=200)
        plt.close(fig)
        print(f"[+] Wrote {out}")

def main():
    labels = load_labels()
    plot_one(cfg.RESULTS_DIR / "metrics_1gram.json", labels)
    plot_one(cfg.RESULTS_DIR / "metrics_2gram.json", labels)

if __name__ == "__main__":
    main()
