#!/usr/bin/env python3
"""
Build manifest.csv linking each .opcode file (Submission 3) to an APT label
(Submission 2 folder name).
"""
import csv
from scripts import config as cfg
from scripts.utils import ensure_dir

def main() -> None:
    ensure_dir(cfg.DATA_PROCESSED_DIR)

    stem_to_label = {}
    for p in cfg.SUB2_EXEC_ROOT.rglob("*"):
        if p.is_file() and p.suffix.lower() in [".exe", ".dll", ".elf"]:
            stem_to_label[p.stem] = p.parent.name

    rows = []
    for op in cfg.SUB3_RAW_OPCODES.glob("*.opcode"):
        stem = op.stem
        label = stem_to_label.get(stem, "UNKNOWN")
        rows.append((stem, label, str(op)))

    out_csv = cfg.DATA_PROCESSED_DIR / "manifest.csv"
    with out_csv.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["sample_id", "label", "opcode_path"])
        w.writerows(rows)

    unknown = sum(1 for _,lab,_ in rows if lab == "UNKNOWN")
    print(f"[+] Wrote {len(rows)} rows to {out_csv}")
    print(f"[!] UNKNOWN labels: {unknown} (should be 0)")

if __name__ == "__main__":
    main()
