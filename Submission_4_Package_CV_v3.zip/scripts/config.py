from pathlib import Path

# === USER PATHS (provided) ===
SUB3_OUTPUT = Path(r"/home/kali/Desktop/SUBMISSION_3_OUTPUT")
SUB2_ROOT   = Path(r"/home/kali/Desktop/cis6530 folder/CIS_6530_Assignment_Submission_2")

# === Derived locations ===
SUB3_RAW_OPCODES = SUB3_OUTPUT / "Raw_Extracted_Files"
SUB2_EXEC_ROOT   = SUB2_ROOT / "Executable_Malware"

# === Local project paths (inside this package/repo) ===
PROJECT_ROOT       = Path(__file__).resolve().parents[1]
DATA_PROCESSED_DIR = PROJECT_ROOT / "data_processed"
RESULTS_DIR        = PROJECT_ROOT / "results"

# === Experiment config ===
RANDOM_SEED = 42
N_SPLITS = 2  # 2-fold Stratified CV

# Assignment says k=3.5. KNN requires integer k.
KNN_K_REQUESTED = 3.5
KNN_K = int(round(KNN_K_REQUESTED))  # rounds 3.5 -> 4
if KNN_K < 1:
    KNN_K = 1
