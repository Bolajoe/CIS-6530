#!/usr/bin/env python3
"""
Train and evaluate SVM, KNN, Decision Tree using 2-fold Stratified Cross-Validation
on both 1-gram and 2-gram feature sets.

Outputs:
  results/metrics_1gram.json
  results/metrics_2gram.json
  results/summary_table.csv
"""
import json, csv
import numpy as np
from scipy import sparse
from sklearn.model_selection import StratifiedKFold
from sklearn.svm import LinearSVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, confusion_matrix

from scripts import config as cfg
from scripts.utils import ensure_dir

def fold_metrics(y_true, y_pred):
    acc = float(accuracy_score(y_true, y_pred))
    prec, rec, f1, _ = precision_recall_fscore_support(y_true, y_pred, average="macro", zero_division=0)
    return {"accuracy": acc, "macro_precision": float(prec), "macro_recall": float(rec), "macro_f1": float(f1)}

def run_cv(feature_set, X, y, labels):
    skf = StratifiedKFold(n_splits=cfg.N_SPLITS, shuffle=True, random_state=cfg.RANDOM_SEED)

    models = [
        ("SVM_Linear", LinearSVC(class_weight="balanced", random_state=cfg.RANDOM_SEED)),
        (f"KNN_k{cfg.KNN_K}_from_{cfg.KNN_K_REQUESTED}", KNeighborsClassifier(n_neighbors=cfg.KNN_K)),
        ("DecisionTree", DecisionTreeClassifier(class_weight="balanced", random_state=cfg.RANDOM_SEED)),
    ]

    out = {
        "feature_set": feature_set,
        "n_samples": int(X.shape[0]),
        "n_features": int(X.shape[1]),
        "n_classes": int(len(np.unique(y))),
        "cv": {"n_splits": cfg.N_SPLITS, "shuffle": True, "random_state": cfg.RANDOM_SEED},
        "models": []
    }

    for name, model in models:
        folds = []
        cm_sum = None
        y_true_all = []
        y_pred_all = []

        for fold_i, (tr, te) in enumerate(skf.split(X, y), start=1):
            model.fit(X[tr], y[tr])
            pred = model.predict(X[te])

            m = fold_metrics(y[te], pred)
            m["fold"] = fold_i
            folds.append(m)

            cm = confusion_matrix(y[te], pred, labels=np.arange(len(labels)))
            cm_sum = cm if cm_sum is None else (cm_sum + cm)

            y_true_all.append(y[te])
            y_pred_all.append(pred)

        y_true_all = np.concatenate(y_true_all)
        y_pred_all = np.concatenate(y_pred_all)
        overall = fold_metrics(y_true_all, y_pred_all)

        # mean/std
        accs = np.array([f["accuracy"] for f in folds], dtype=float)
        precs = np.array([f["macro_precision"] for f in folds], dtype=float)
        recs = np.array([f["macro_recall"] for f in folds], dtype=float)
        f1s = np.array([f["macro_f1"] for f in folds], dtype=float)

        out["models"].append({
            "model": name,
            "folds": folds,
            "mean": {
                "accuracy": float(accs.mean()),
                "macro_precision": float(precs.mean()),
                "macro_recall": float(recs.mean()),
                "macro_f1": float(f1s.mean())
            },
            "std": {
                "accuracy": float(accs.std(ddof=0)),
                "macro_precision": float(precs.std(ddof=0)),
                "macro_recall": float(recs.std(ddof=0)),
                "macro_f1": float(f1s.std(ddof=0))
            },
            "overall": overall,
            "confusion_matrix_sum": cm_sum.tolist()
        })

    return out

def main():
    ensure_dir(cfg.RESULTS_DIR)

    label_map = json.loads((cfg.DATA_PROCESSED_DIR / "label_encoder.json").read_text(encoding="utf-8"))
    labels = [label_map[str(i)] for i in range(len(label_map))]

    y = np.load(cfg.DATA_PROCESSED_DIR / "y.npy")
    X1 = sparse.load_npz(cfg.DATA_PROCESSED_DIR / "X_1gram.npz")
    X2 = sparse.load_npz(cfg.DATA_PROCESSED_DIR / "X_2gram.npz")

    r1 = run_cv("1gram", X1, y, labels)
    r2 = run_cv("2gram", X2, y, labels)

    (cfg.RESULTS_DIR / "metrics_1gram.json").write_text(json.dumps(r1, indent=2), encoding="utf-8")
    (cfg.RESULTS_DIR / "metrics_2gram.json").write_text(json.dumps(r2, indent=2), encoding="utf-8")
    print("[+] Wrote results/metrics_1gram.json and results/metrics_2gram.json")

    out_csv = cfg.RESULTS_DIR / "summary_table.csv"
    with out_csv.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["features","model","mean_accuracy","std_accuracy","mean_macro_precision","mean_macro_recall","mean_macro_f1"])
        for feats, obj in [("1gram", r1), ("2gram", r2)]:
            for m in obj["models"]:
                w.writerow([feats, m["model"], m["mean"]["accuracy"], m["std"]["accuracy"],
                            m["mean"]["macro_precision"], m["mean"]["macro_recall"], m["mean"]["macro_f1"]])
    print(f"[+] Wrote {out_csv}")

if __name__ == "__main__":
    main()
