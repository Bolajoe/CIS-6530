#!/usr/bin/env python3
"""
Create a Submission 4 ZIP with scripts + processed dataset + results.
"""
import zipfile
from pathlib import Path
from scripts import config as cfg

def add_dir(z: zipfile.ZipFile, folder: Path, arc_prefix: str):
    for p in folder.rglob("*"):
        if p.is_file():
            z.write(p, str(Path(arc_prefix) / p.relative_to(folder)))

def main():
    out_zip = cfg.PROJECT_ROOT / "Submission_4_Artifacts.zip"
    if out_zip.exists():
        out_zip.unlink()

    with zipfile.ZipFile(out_zip, "w", compression=zipfile.ZIP_DEFLATED) as z:
        add_dir(z, cfg.PROJECT_ROOT / "scripts", "scripts")
        add_dir(z, cfg.PROJECT_ROOT / "data_processed", "data_processed")
        add_dir(z, cfg.PROJECT_ROOT / "results", "results")
        readme = cfg.PROJECT_ROOT / "README.md"
        if readme.exists():
            z.write(readme, "README.md")

    print(f"[+] Wrote {out_zip}")

if __name__ == "__main__":
    main()
