#!/usr/bin/env python3
"""
Preprocess .opcode files into 1-gram and 2-gram count feature matrices.
Filters labels with < N_SPLITS samples (required for StratifiedKFold with n_splits=2).
"""
import csv, json
from collections import Counter
from pathlib import Path

import numpy as np
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.preprocessing import LabelEncoder
from scipy import sparse
import joblib

from scripts import config as cfg
from scripts.utils import ensure_dir

def load_tokens(path: Path):
    tokens = []
    for line in path.read_text(errors="ignore").splitlines():
        line = line.strip()
        if (not line) or line.startswith("#") or line.startswith("<FUNCTION>"):
            continue
        tokens.append(line)
    return tokens

def main() -> None:
    ensure_dir(cfg.DATA_PROCESSED_DIR)

    manifest = cfg.DATA_PROCESSED_DIR / "manifest.csv"
    if not manifest.exists():
        raise FileNotFoundError("manifest.csv not found. Run: python -m scripts.01_build_manifest")

    with manifest.open("r", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))

    label_counts = Counter(row["label"] for row in rows)
    keep_labels = {lab for lab, c in label_counts.items() if c >= cfg.N_SPLITS}
    drop_labels = {lab for lab, c in label_counts.items() if c < cfg.N_SPLITS}

    filtered = [row for row in rows if row["label"] in keep_labels]
    dropped  = [row for row in rows if row["label"] in drop_labels]

    out_dropped = cfg.DATA_PROCESSED_DIR / "filtered_out_classes.csv"
    with out_dropped.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["sample_id","label","opcode_path"])
        for row in dropped:
            w.writerow([row["sample_id"], row["label"], row["opcode_path"]])

    out_counts = cfg.DATA_PROCESSED_DIR / "class_counts.csv"
    with out_counts.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["label","count","kept"])
        for lab, c in sorted(label_counts.items(), key=lambda x: (-x[1], x[0])):
            w.writerow([lab, c, "yes" if lab in keep_labels else "no"])

    print(f"[+] Total samples in manifest: {len(rows)}")
    print(f"[+] Total classes in manifest: {len(label_counts)}")
    print(f"[+] Kept samples (labels >= {cfg.N_SPLITS}): {len(filtered)}")
    print(f"[+] Filtered out samples (labels < {cfg.N_SPLITS}): {len(dropped)}")
    print(f"[+] Filtered out labels: {sorted(drop_labels)}")

    ids, labels, texts = [], [], []
    for row in filtered:
        p = Path(row["opcode_path"])
        toks = load_tokens(p)
        ids.append(row["sample_id"])
        labels.append(row["label"])
        texts.append(" ".join(toks))

    le = LabelEncoder()
    y = le.fit_transform(labels)

    (cfg.DATA_PROCESSED_DIR / "ids.json").write_text(json.dumps(ids, indent=2), encoding="utf-8")
    label_map = {int(i): c for i, c in enumerate(le.classes_)}
    (cfg.DATA_PROCESSED_DIR / "label_encoder.json").write_text(json.dumps(label_map, indent=2), encoding="utf-8")
    np.save(cfg.DATA_PROCESSED_DIR / "y.npy", y)

    vec1 = CountVectorizer(ngram_range=(1,1), token_pattern=r"(?u)\b\w+\b")
    X1 = vec1.fit_transform(texts)
    joblib.dump(vec1, cfg.DATA_PROCESSED_DIR / "vectorizer_1gram.pkl")
    sparse.save_npz(cfg.DATA_PROCESSED_DIR / "X_1gram.npz", X1)

    vec2 = CountVectorizer(ngram_range=(2,2), token_pattern=r"(?u)\b\w+\b")
    X2 = vec2.fit_transform(texts)
    joblib.dump(vec2, cfg.DATA_PROCESSED_DIR / "vectorizer_2gram.pkl")
    sparse.save_npz(cfg.DATA_PROCESSED_DIR / "X_2gram.npz", X2)

    print(f"[+] 1gram: X={X1.shape}, vocab={len(vec1.vocabulary_)}")
    print(f"[+] 2gram: X={X2.shape}, vocab={len(vec2.vocabulary_)}")
    print("[+] Preprocessing complete.")

if __name__ == "__main__":
    main()
