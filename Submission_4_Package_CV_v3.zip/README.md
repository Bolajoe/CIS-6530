# CIS*6530 — Submission 4 (2-fold Stratified Cross-Validation)

Configured paths:
- Submission 3 output: /home/kali/Desktop/SUBMISSION_3_OUTPUT
- Submission 2 root: /home/kali/Desktop/cis6530 folder/CIS_6530_Assignment_Submission_2

## Why 2-fold Stratified CV
With many classes and limited samples, a single stratified train/test split can be invalid (e.g., test set too small to include all classes).
We use **2-fold StratifiedKFold** on labels with >=2 samples. Labels with <2 samples are filtered and logged.

## KNN k=3.5
KNN requires integer k. We use round(3.5)=4 and record it.

## Setup
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## Run
```bash
python -m scripts.01_build_manifest
python -m scripts.02_preprocess_vectorize
python -m scripts.03_train_eval_models
python -m scripts.04_plot_metrics
python -m scripts.05_make_final_zip
```

## Outputs
- data_processed/: manifest, filtered_out_classes.csv, class_counts.csv, ids.json, y.npy, X_1gram.npz, X_2gram.npz, vectorizers
- results/: metrics_1gram.json, metrics_2gram.json, summary_table.csv, confusion_*.png
- Submission_4_Artifacts.zip
