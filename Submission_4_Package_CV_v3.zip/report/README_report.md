Place your Submission 4 technical report PDF here.
