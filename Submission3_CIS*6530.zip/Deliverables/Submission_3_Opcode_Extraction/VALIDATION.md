# Validation Checklist (Submission 3)

## Required checks
1. **Count match:** number of executables == number of `.opcode` outputs.
2. **Stem match:** output filename stems exactly match Submission 2 executable stems.
3. **Non-empty:** `.opcode` files are not empty; contain at least one `[function]` section.
4. **Logs present:** per-binary logs exist for auditability (`logs/<binary>.log`).

## Suggested checks (higher grade)
- Re-run on the same Ghidra version and compare instruction counts for stability.
- Flag likely-packed samples (high entropy / suspicious section layout) and note in report.
- Embed Submission 2 SHA-256 inventory into `.opcode` headers (v2 does this when original path is provided).


## Naming compliance check
- For each sample `SAMPLE.ext`, confirm the presence of:
  - `<OUTDIR>/SAMPLE_output/Raw_Extracted_Files/SAMPLE.opcode`
- Confirm `.opcode` stems match Submission 2 malware names exactly.
