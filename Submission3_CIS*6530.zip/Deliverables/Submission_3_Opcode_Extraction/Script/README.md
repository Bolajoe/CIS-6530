# Submission 3 - Automated OpCode Extraction (Ghidra, Headless)

This package is designed to satisfy **CIS*6510 Submission 3** deliverables:

1. **Raw Extracted Files**: `.opcode` files that match the malware names from Submission 2.
2. **Automation Script(s)**: a reproducible, parameterized pipeline for batch extraction.
3. **Technical Report**: submitted separately to CourseLink.

## Safety and Ethics (Important)
- This pipeline performs **static analysis only** (Ghidra disassembly). It does **not** execute malware.
- Run in an **isolated VM** and treat samples as hazardous. Disable shared folders unless required.

---

## Folder Layout

```
Submission_3_Opcode_Extraction/
  Raw_Extracted_Files/           # Example outputs (already named like Submission 2 stems)
  Script/
    export_opcodes_clean_v3.java # GhidraScript extractor (headless-friendly)
    run_ghidra_batch_v3.sh       # Batch runner for analyzeHeadless
    README.md
  logs/                          # Optional (your run logs)
  VALIDATION.md
```

### Output layout (when you run the pipeline)

For each input executable named `SAMPLE.exe` (SAMPLE = malware name/stem from Submission 2):

```
<OUTDIR>/SAMPLE_output/
  Raw_Extracted_Files/SAMPLE.opcode   # merged mnemonics-only file (ML-ready)
  opcodes/*.opcode                    # per-function traces (address | bytes | mnemonic | operands)
  log.txt
  metadata.json
  manifest.json
  summary.json
```

**Naming compliance:** The merged file is named `SAMPLE.opcode` where SAMPLE is the **input filename stem**, aligning with Submission 2 malware naming requirements.

---

## Dependencies
- Ghidra (tested with 10.x-12.x)
- Java (bundled with Ghidra or system Java)
- Bash (Linux/macOS) or WSL on Windows for the batch runner

---

## How to Run (Headless Batch)

1) Put malware binaries in a folder, e.g. `./samples/` with names matching Submission 2:
- `APT29_WellMess_Backdoor.exe`
- `admin338_PlugX_RAT.exe`

2) Run:

```bash
chmod +x Script/run_ghidra_batch_v3.sh
./Script/run_ghidra_batch_v3.sh   --ghidra /opt/ghidra_12.0   --input  ./samples   --out    ./out   --proj   ./ghidra_projects
```

3) Collect your `.opcode` files from:
`./out/*_output/Raw_Extracted_Files/*.opcode`

---

## Output Format (Merged `.opcode`)
The merged file is **mnemonics-only** with function markers:

```
# sample_stem=APT29_WellMess_Backdoor
<FUNCTION> FUN_140001030 140001030
MOV
PUSH
CALL
...
```

This format is deliberately ML-friendly for 1-gram/2-gram feature extraction in later submissions.

---

## Troubleshooting
- **Packed samples** may produce low-quality disassembly. See the report's limitations section.
- Increase `-analysisTimeoutPerFile` in the batch script for large binaries.
- If a binary fails to import, confirm it is a supported executable format.

---

## Validation
See `VALIDATION.md` for a quick checklist and expected artifacts.
