// export_opcodes_clean_v3.java
// Masters-level, rubric-aligned OpCode extractor for Ghidra.
// - Headless-friendly (reads output directory from script args).
// - Produces BOTH per-function opcode traces and a single per-sample .opcode for ML + naming compliance.
//
// Output (under <baseOutput>/<sampleStem>_output/):
//   Raw_Extracted_Files/<sampleStem>.opcode      (merged mnemonics-only with function markers)
//   opcodes/<function>.opcode                   (address | machine_bytes | mnemonic | operands)
//   metadata.json, manifest.json, summary.json, log.txt
//
// Notes:
// - "machine_bytes" are the instruction encoding bytes returned by Instruction.getBytes()
//   (opcode + ModRM/SIB/immediate as applicable). Mnemonic is used as the ML token by default.
//
// Tested with: Ghidra 10.x/11.x/12.x (GhidraScript API compatible)

import ghidra.app.script.GhidraScript;
import ghidra.program.model.listing.*;
import ghidra.program.model.address.Address;
import ghidra.program.model.lang.Language;
import ghidra.program.model.lang.CompilerSpec;

import java.io.*;

public class export_opcodes_clean_v3 extends GhidraScript {

    // ---- ML / extraction controls ----
    private static final boolean INCLUDE_OPERANDS_IN_FUNC_FILES = true; // richer per-function traces
    private static final boolean MERGED_MNEMONICS_ONLY = true;          // best for n-grams (Submission 4 ready)
    private static final int MAX_INSTRUCTIONS_PER_FUNCTION = 250000;    // guardrails for packed/huge samples
    private static final long MAX_TOTAL_INSTRUCTIONS = 5000000L;

    @Override
    public void run() throws Exception {

        // Headless arg: base output directory
        // Usage (headless): -postScript export_opcodes_clean_v3.java <baseOutputDir>
        String[] args = getScriptArgs();
        File baseDir;
        if (args != null && args.length >= 1 && args[0] != null && args[0].trim().length() > 0) {
            baseDir = new File(args[0].trim());
        } else {
            baseDir = askDirectory("Select Base Output Directory", "OK");
        }
        if (!baseDir.exists()) {
            baseDir.mkdirs();
        }

        Listing listing = currentProgram.getListing();
        FunctionManager fm = currentProgram.getFunctionManager();
        FunctionIterator funcs = fm.getFunctions(true);

        // Use input filename stem for naming compliance (align with Submission 2 stem)
        String sampleStem = stem(currentProgram.getName());

        File sampleDir = new File(baseDir, sampleStem + "_output");
        if (!sampleDir.exists()) sampleDir.mkdir();

        File opcodeDir = new File(sampleDir, "opcodes");
        if (!opcodeDir.exists()) opcodeDir.mkdir();

        File rawDir = new File(sampleDir, "Raw_Extracted_Files");
        if (!rawDir.exists()) rawDir.mkdir();

        PrintWriter logWriter = new PrintWriter(new BufferedWriter(new FileWriter(new File(sampleDir, "log.txt"))));
        PrintWriter metadataWriter = new PrintWriter(new BufferedWriter(new FileWriter(new File(sampleDir, "metadata.json"))));
        PrintWriter manifestWriter = new PrintWriter(new BufferedWriter(new FileWriter(new File(sampleDir, "manifest.json"))));
        PrintWriter summaryWriter = new PrintWriter(new BufferedWriter(new FileWriter(new File(sampleDir, "summary.json"))));

        File mergedOpcodeFile = new File(rawDir, sampleStem + ".opcode");
        PrintWriter mergedWriter = new PrintWriter(new BufferedWriter(new FileWriter(mergedOpcodeFile)));

        // Program metadata
        Language lang = currentProgram.getLanguage();
        CompilerSpec cs = currentProgram.getCompilerSpec();

        String arch = lang.getProcessor().toString();
        String endian = lang.isBigEndian() ? "big" : "little";
        String languageID = lang.getLanguageID().toString();
        String compilerID = cs.getCompilerSpecID().toString();

        // Merged header: minimal provenance (safe + rubric-friendly)
        mergedWriter.println("# sample_stem=" + sampleStem);
        mergedWriter.println("# architecture=" + arch);
        mergedWriter.println("# endianness=" + endian);
        mergedWriter.println("# language_id=" + languageID);
        mergedWriter.println("# compiler_spec=" + compilerID);
        mergedWriter.println("# tokenization=MNEMONICS_ONLY_WITH_FUNCTION_MARKERS");
        mergedWriter.println();

        // metadata.json (program + functions list)
        metadataWriter.println("{");
        metadataWriter.println("  \"sample_stem\": \"" + esc(sampleStem) + "\",");
        metadataWriter.println("  \"program_name\": \"" + esc(currentProgram.getName()) + "\",");
        metadataWriter.println("  \"language_id\": \"" + esc(languageID) + "\",");
        metadataWriter.println("  \"architecture\": \"" + esc(arch) + "\",");
        metadataWriter.println("  \"endianness\": \"" + esc(endian) + "\",");
        metadataWriter.println("  \"compiler_spec\": \"" + esc(compilerID) + "\",");
        metadataWriter.println("  \"functions\": [");

        // manifest.json
        manifestWriter.println("{");
        manifestWriter.println("  \"sample_stem\": \"" + esc(sampleStem) + "\",");
        manifestWriter.println("  \"outputs\": [");

        boolean firstFunc = true;
        boolean firstOut = true;

        int totalFunctions = 0;
        long totalInstructions = 0;
        int skippedFunctions = 0;
        int truncatedFunctions = 0;

        while (funcs.hasNext() && !monitor.isCancelled()) {
            Function func = funcs.next();
            totalFunctions++;

            String funcName = sanitize(func.getName());
            Address startAddr = func.getEntryPoint();

            File funcFile = new File(opcodeDir, funcName + ".opcode");
            PrintWriter funcWriter = new PrintWriter(new BufferedWriter(new FileWriter(funcFile)));

            InstructionIterator it = listing.getInstructions(func.getBody(), true);

            int instructionCount = 0;
            boolean truncated = false;

            mergedWriter.println("<FUNCTION> " + funcName + " " + startAddr.toString());

            while (it.hasNext()) {
                if (instructionCount >= MAX_INSTRUCTIONS_PER_FUNCTION) {
                    truncated = true;
                    break;
                }
                if (totalInstructions >= MAX_TOTAL_INSTRUCTIONS) {
                    logWriter.println("STOP: Reached MAX_TOTAL_INSTRUCTIONS at function " + funcName);
                    break;
                }

                Instruction instr = it.next();

                String address = instr.getAddress().toString();
                String machineBytesHex = bytesToHex(instr.getBytes());
                String mnemonic = instr.getMnemonicString();
                String operands = instr.getDefaultOperandRepresentation();

                if (INCLUDE_OPERANDS_IN_FUNC_FILES) {
                    funcWriter.printf("%s | %s | %s | %s%n",
                            address,
                            machineBytesHex,
                            mnemonic,
                            operands == null ? "" : operands);
                } else {
                    funcWriter.printf("%s | %s | %s%n", address, machineBytesHex, mnemonic);
                }

                if (MERGED_MNEMONICS_ONLY) {
                    mergedWriter.println(mnemonic);
                } else {
                    mergedWriter.println(mnemonic + " " + (operands == null ? "" : operands));
                }

                instructionCount++;
                totalInstructions++;
            }

            mergedWriter.println();
            funcWriter.close();

            if (instructionCount == 0) {
                skippedFunctions++;
                logWriter.println("Skipped (0 instr): " + funcName);
            } else {
                logWriter.println("Processed: " + funcName + " | Instructions: " + instructionCount);
            }

            if (truncated) {
                truncatedFunctions++;
                logWriter.println("Truncated: " + funcName + " at " + MAX_INSTRUCTIONS_PER_FUNCTION);
            }

            // metadata function entry
            if (!firstFunc) metadataWriter.println(",");
            metadataWriter.println("    {");
            metadataWriter.println("      \"function_name\": \"" + esc(funcName) + "\",");
            metadataWriter.println("      \"start_address\": \"" + esc(startAddr.toString()) + "\",");
            metadataWriter.println("      \"instruction_count\": " + instructionCount + ",");
            metadataWriter.println("      \"truncated\": " + truncated);
            metadataWriter.print("    }");
            firstFunc = false;

            // manifest outputs
            if (!firstOut) manifestWriter.println(",");
            manifestWriter.println("    {");
            manifestWriter.println("      \"type\": \"function_opcode_file\",");
            manifestWriter.println("      \"path\": \"opcodes/" + esc(funcName) + ".opcode\",");
            manifestWriter.println("      \"instruction_count\": " + instructionCount);
            manifestWriter.print("    }");
            firstOut = false;

            if (totalInstructions >= MAX_TOTAL_INSTRUCTIONS) break;
        }

        // Close metadata + manifest
        metadataWriter.println();
        metadataWriter.println("  ]");
        metadataWriter.println("}");
        metadataWriter.close();

        if (!firstOut) manifestWriter.println(",");
        manifestWriter.println("    {");
        manifestWriter.println("      \"type\": \"merged_sample_opcode_file\",");
        manifestWriter.println("      \"path\": \"Raw_Extracted_Files/" + esc(sampleStem) + ".opcode\"");
        manifestWriter.println("    }");
        manifestWriter.println("  ]");
        manifestWriter.println("}");
        manifestWriter.close();

        summaryWriter.println("{");
        summaryWriter.println("  \"sample_stem\": \"" + esc(sampleStem) + "\",");
        summaryWriter.println("  \"total_functions\": " + totalFunctions + ",");
        summaryWriter.println("  \"skipped_functions_zero_instr\": " + skippedFunctions + ",");
        summaryWriter.println("  \"truncated_functions\": " + truncatedFunctions + ",");
        summaryWriter.println("  \"total_instructions\": " + totalInstructions + ",");
        summaryWriter.println("  \"merged_output\": \"Raw_Extracted_Files/" + esc(sampleStem) + ".opcode\",");
        summaryWriter.println("  \"notes\": [");
        summaryWriter.println("    \"Merged output is mnemonics-only (one token per line) with <FUNCTION> markers; ideal for 1-gram/2-gram models.\",");
        summaryWriter.println("    \"Per-function traces retain address and full instruction encoding bytes for auditability.\",");
        summaryWriter.println("    \"Guardrails mitigate runaway extraction on packed/obfuscated samples.\"");
        summaryWriter.println("  ]");
        summaryWriter.println("}");
        summaryWriter.close();

        mergedWriter.close();

        logWriter.println("Total Functions: " + totalFunctions);
        logWriter.println("Total Instructions: " + totalInstructions);
        logWriter.println("Merged Output: " + mergedOpcodeFile.getAbsolutePath());
        logWriter.close();

        popup("Extraction complete.\nOutput folder:\n" + sampleDir.getAbsolutePath());
    }

    private String stem(String filename) {
        String s = filename == null ? "unknown" : filename;
        // Strip path-like separators just in case
        s = s.replace("\\", "/");
        int slash = s.lastIndexOf("/");
        if (slash >= 0) s = s.substring(slash + 1);
        // Strip extension
        int dot = s.lastIndexOf(".");
        if (dot > 0) s = s.substring(0, dot);
        return sanitize(s);
    }

    private String sanitize(String s) {
        if (s == null) return "unknown";
        return s.replaceAll("[^a-zA-Z0-9_\\-]", "_");
    }

    private String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private String bytesToHex(byte[] bytes) {
        if (bytes == null) return "";
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) sb.append(String.format("%02X", b));
        return sb.toString();
    }
}
