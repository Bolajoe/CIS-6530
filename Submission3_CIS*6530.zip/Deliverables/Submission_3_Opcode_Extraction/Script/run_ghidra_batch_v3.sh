#!/usr/bin/env bash
set -euo pipefail

# run_ghidra_batch_v3.sh
#
# Purpose:
#   Batch process executables with Ghidra headless and export OpCodes in a rubric-aligned format.
#
# What you get:
#   For each input executable "SAMPLE.ext", outputs:
#     <OUTDIR>/SAMPLE_output/Raw_Extracted_Files/SAMPLE.opcode     (mnemonics-only, 1 token per line)
#     <OUTDIR>/SAMPLE_output/opcodes/*.opcode                      (per-function traces)
#     <OUTDIR>/SAMPLE_output/log.txt, metadata.json, manifest.json, summary.json
#
# Naming compliance:
#   The merged file name is the INPUT STEM (SAMPLE) to match Submission 2 malware names.
#
# Usage:
#   ./run_ghidra_batch_v3.sh \
#     --ghidra /path/to/ghidra \
#     --input /path/to/malware_binaries \
#     --out   /path/to/output \
#     --proj  /path/to/ghidra_projects
#
# Notes:
#   - Safe: static analysis only (Ghidra disassembly), no execution/detonation.
#   - Recommended: run inside an isolated VM/sandbox.

GHIDRA_DIR=""
INPUT_DIR=""
OUT_DIR=""
PROJ_DIR=""
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --ghidra) GHIDRA_DIR="$2"; shift 2;;
    --input)  INPUT_DIR="$2"; shift 2;;
    --out)    OUT_DIR="$2"; shift 2;;
    --proj)   PROJ_DIR="$2"; shift 2;;
    *) echo "Unknown arg: $1"; exit 1;;
  esac
done

if [[ -z "$GHIDRA_DIR" || -z "$INPUT_DIR" || -z "$OUT_DIR" || -z "$PROJ_DIR" ]]; then
  echo "Missing args."
  echo "Example:"
  echo "  $0 --ghidra /opt/ghidra --input ./samples --out ./out --proj ./ghidra_projects"
  exit 1
fi

ANALYZE="$GHIDRA_DIR/support/analyzeHeadless"
if [[ ! -x "$ANALYZE" ]]; then
  echo "analyzeHeadless not found or not executable at: $ANALYZE"
  exit 1
fi

mkdir -p "$OUT_DIR" "$PROJ_DIR"

# GhidraScript path (java script lives in this folder)
SCRIPT_PATH="$SCRIPT_DIR"
POST_SCRIPT="export_opcodes_clean_v3.java"

echo "[*] Ghidra: $GHIDRA_DIR"
echo "[*] Input:  $INPUT_DIR"
echo "[*] Output: $OUT_DIR"
echo "[*] Project:$PROJ_DIR"
echo "[*] Script: $POST_SCRIPT"

shopt -s nullglob
count=0
fail=0

for f in "$INPUT_DIR"/*; do
  [[ -f "$f" ]] || continue
  count=$((count+1))

  base="$(basename "$f")"
  stem="${base%.*}"
  projName="proj_${stem}"
  echo "[*] Processing: $base"

  # Run Ghidra headless:
  # - import the binary
  # - analyze
  # - run postScript and pass OUT_DIR as its base output directory
  set +e
  "$ANALYZE" "$PROJ_DIR" "$projName" \
    -import "$f" \
    -analysisTimeoutPerFile 60 \
    -scriptPath "$SCRIPT_PATH" \
    -postScript "$POST_SCRIPT" "$OUT_DIR" \
    -deleteProject \
    > "$OUT_DIR/${stem}_ghidra_stdout.log" 2> "$OUT_DIR/${stem}_ghidra_stderr.log"
  rc=$?
  set -e

  if [[ $rc -ne 0 ]]; then
    echo "[!] FAILED: $base (exit $rc)"
    fail=$((fail+1))
    continue
  fi

  # Quick compliance check:
  expected="$OUT_DIR/${stem}_output/Raw_Extracted_Files/${stem}.opcode"
  if [[ ! -f "$expected" ]]; then
    echo "[!] WARNING: Missing merged opcode file: $expected"
  fi
done

echo "[*] Done. Total: $count | Failed: $fail"
echo "[*] Outputs are under: $OUT_DIR"
