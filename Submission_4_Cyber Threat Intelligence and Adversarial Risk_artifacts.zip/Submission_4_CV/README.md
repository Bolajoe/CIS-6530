# CIS 6530 — Submission 4: Multi-Class OpCode Classification for APT Attribution

---

## Overview

This package evaluates three classifier families on 1-gram and 2-gram OpCode
feature representations extracted from APT-labelled malware binaries:

- **LinearSVC** — linear Support Vector Machine
- **KNN** — k-Nearest Neighbours evaluated at **k = 3, 4, and 5** (as specified)
- **Decision Tree** — CART classifier

Evaluation uses 2-fold Stratified Cross-Validation. All five metrics required
by the rubric are reported: Accuracy, Precision, Recall, F-measure, and
Confusion Matrix.

---

## Repository Structure

```
Submission_4_CV/
├── scripts/
│   ├── config.py                  # Paths and experiment parameters
│   ├── utils.py                   # Shared helpers
│   ├── 01_build_manifest.py       # Link .opcode files to APT labels
│   ├── 02_preprocess_vectorize.py # Parse + vectorise → 1-gram / 2-gram matrices
│   ├── 03_train_eval_models.py    # CV experiments (SVM, KNN k=3/4/5, DecTree)
│   ├── 04_plot_metrics.py         # Confusion matrices + metric bar charts
│   └── 05_make_final_zip.py       # Package deliverables into submission ZIP
├── data_processed/
│   ├── manifest.csv
│   ├── filtered_out_classes.csv   # Excluded singleton labels
│   ├── class_counts.csv
│   ├── ids.json
│   ├── label_encoder.json
│   ├── y.npy
│   ├── X_1gram.npz                # 59 × 542
│   ├── X_2gram.npz                # 59 × 10,063
│   ├── vectorizer_1gram.pkl
│   └── vectorizer_2gram.pkl
├── results/
│   ├── metrics_1gram.json
│   ├── metrics_2gram.json
│   ├── summary_table.csv
│   ├── confusion_*.png            # 10 confusion matrices
│   ├── bar_*.png / compare_*.png  # Metric charts
│   └── additional_figures/
├── README.md
└── requirements.txt
```

---

## Setup

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

Open `scripts/config.py` and update the two path variables:

```python
SUB3_OUTPUT = Path(r"/path/to/SUBMISSION_3_OUTPUT")
SUB2_ROOT   = Path(r"/path/to/CIS_6530_Assignment_Submission_2")
```

---

## Run Instructions

Execute in order from the project root:

```bash
python -m scripts.01_build_manifest
python -m scripts.02_preprocess_vectorize
python -m scripts.03_train_eval_models
python -m scripts.04_plot_metrics
python -m scripts.05_make_final_zip
```

---

## Experiment Configuration

| Parameter | Value |
|-----------|-------|
| Cross-validation | StratifiedKFold (n_splits=2, shuffle=True, random_state=42) |
| Random seed | 42 |
| Min class support | 2 samples (labels with < 2 excluded) |
| Excluded labels | G0023_APT16, G0045_menuPass, G0064_APT33 |
| Retained samples | 59 across 29 APT labels |
| 1-gram features | 542 |
| 2-gram features | 10,063 |
| KNN k-values | 3, 4, 5 (all evaluated separately) |

---

## Results Summary

| Features | Model | Mean Accuracy | Macro F1 |
|----------|-------|:---:|:---:|
| 1-gram | LinearSVC | 0.1529 | 0.1153 |
| 1-gram | KNN (k=3) | 0.1011 | 0.0601 |
| 1-gram | KNN (k=4) | 0.0845 | 0.0356 |
| 1-gram | KNN (k=5) | 0.0845 | 0.0354 |
| 1-gram | Decision Tree | 0.2040 | 0.1534 |
| **2-gram** | **LinearSVC ★** | **0.2546** | **0.1775** |
| 2-gram | KNN (k=3) | 0.1011 | 0.0596 |
| 2-gram | KNN (k=4) | 0.0672 | 0.0199 |
| 2-gram | KNN (k=5) | 0.0672 | 0.0174 |
| 2-gram | Decision Tree | 0.2207 | 0.1925 |

★ Best overall configuration.

---

## Dependencies

```
numpy>=1.24,<2.0
scipy>=1.10,<2.0
scikit-learn>=1.3,<2.0
matplotlib>=3.7,<4.0
joblib>=1.3,<2.0
```
