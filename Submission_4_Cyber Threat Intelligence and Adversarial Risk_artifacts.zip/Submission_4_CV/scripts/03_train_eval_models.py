#!/usr/bin/env python3
"""
03_train_eval_models.py — Train and evaluate classifiers with 2-fold Stratified CV
====================================================================================
Evaluates the following classifiers on both 1-gram and 2-gram feature matrices:

    1. LinearSVC                   — linear Support Vector Machine
    2. KNN (k=3)                   — k-Nearest Neighbours, k=3
    3. KNN (k=4)                   — k-Nearest Neighbours, k=4
    4. KNN (k=5)                   — k-Nearest Neighbours, k=5
    5. DecisionTree                — CART decision tree

All three KNN values (k=3, 4, 5) are evaluated as specified by the rubric.
Separate confusion matrices and fold-level metrics are recorded for each.

Evaluation methodology
-----------------------
- StratifiedKFold(n_splits=2, shuffle=True, random_state=42)
- Stratification preserves class proportions across both folds.
- 2-fold design matches the minimum class support in this dataset
  (many APT labels contribute exactly 2 samples).

Metrics reported
----------------
    Accuracy          — overall fraction of correct predictions
    Macro Precision   — unweighted mean per-class precision
    Macro Recall      — unweighted mean per-class recall
    Macro F1          — harmonic mean of macro-P and macro-R
    Confusion Matrix  — aggregated (summed) over both folds

Macro averaging is emphasised because accuracy alone would mask failure
on low-support APT labels in this imbalanced multiclass setting.

Outputs
-------
    results/metrics_1gram.json
    results/metrics_2gram.json
    results/summary_table.csv

Usage
-----
    python -m scripts.03_train_eval_models   (run after 02)

Course    : CIS 6530 — Cybersecurity and Threat Intelligence
Submission: 4 — Multi-class OpCode Classification
"""

import csv
import json

import numpy as np
from scipy import sparse
from sklearn.model_selection import StratifiedKFold
from sklearn.svm import LinearSVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import (
    accuracy_score,
    precision_recall_fscore_support,
    confusion_matrix,
)

from scripts import config as cfg
from scripts.utils import ensure_dir


def fold_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> dict:
    """Return accuracy and macro-averaged Precision, Recall, F1 as a dict."""
    acc = float(accuracy_score(y_true, y_pred))
    prec, rec, f1, _ = precision_recall_fscore_support(
        y_true, y_pred, average="macro", zero_division=0
    )
    return {
        "accuracy":        acc,
        "macro_precision": float(prec),
        "macro_recall":    float(rec),
        "macro_f1":        float(f1),
    }


def run_cv(feature_set: str, X: sparse.csr_matrix,
           y: np.ndarray, labels: list) -> dict:
    """Run 2-fold Stratified CV for all classifiers on one feature matrix.

    Parameters
    ----------
    feature_set : str   e.g. '1gram' or '2gram'
    X           : sparse count matrix (n_samples × n_features)
    y           : integer label array  (n_samples,)
    labels      : ordered APT label strings (index == y integer code)

    Returns
    -------
    dict  with fold-level metrics, mean/std, overall aggregate, and
          aggregated confusion matrices for every classifier configuration.
    """
    skf = StratifiedKFold(
        n_splits=cfg.N_SPLITS, shuffle=True, random_state=cfg.RANDOM_SEED
    )

    # Build classifier list — KNN evaluated for every k in {3, 4, 5}
    models = [
        ("SVM_Linear", LinearSVC(class_weight="balanced", random_state=cfg.RANDOM_SEED)),
    ]
    for k in cfg.KNN_K_VALUES:
        models.append((f"KNN_k{k}", KNeighborsClassifier(n_neighbors=k)))
    models.append(
        ("DecisionTree", DecisionTreeClassifier(
            class_weight="balanced", random_state=cfg.RANDOM_SEED))
    )

    out = {
        "feature_set": feature_set,
        "n_samples":   int(X.shape[0]),
        "n_features":  int(X.shape[1]),
        "n_classes":   int(len(np.unique(y))),
        "cv": {"n_splits": cfg.N_SPLITS, "shuffle": True,
               "random_state": cfg.RANDOM_SEED},
        "models": [],
    }

    for name, model in models:
        folds      = []
        cm_sum     = None
        yt_all, yp_all = [], []

        for fold_i, (tr, te) in enumerate(skf.split(X, y), start=1):
            model.fit(X[tr], y[tr])
            preds = model.predict(X[te])

            m = fold_metrics(y[te], preds)
            m["fold"] = fold_i
            folds.append(m)

            cm = confusion_matrix(y[te], preds, labels=np.arange(len(labels)))
            cm_sum = cm if cm_sum is None else (cm_sum + cm)

            yt_all.append(y[te])
            yp_all.append(preds)

        yt_cat = np.concatenate(yt_all)
        yp_cat = np.concatenate(yp_all)
        overall = fold_metrics(yt_cat, yp_cat)

        accs  = np.array([f["accuracy"]        for f in folds])
        precs = np.array([f["macro_precision"]  for f in folds])
        recs  = np.array([f["macro_recall"]     for f in folds])
        f1s   = np.array([f["macro_f1"]         for f in folds])

        out["models"].append({
            "model":  name,
            "folds":  folds,
            "mean":   {
                "accuracy":        float(accs.mean()),
                "macro_precision": float(precs.mean()),
                "macro_recall":    float(recs.mean()),
                "macro_f1":        float(f1s.mean()),
            },
            "std":    {
                "accuracy":        float(accs.std(ddof=0)),
                "macro_precision": float(precs.std(ddof=0)),
                "macro_recall":    float(recs.std(ddof=0)),
                "macro_f1":        float(f1s.std(ddof=0)),
            },
            "overall":              overall,
            "confusion_matrix_sum": cm_sum.tolist(),
        })

    return out


def main() -> None:
    ensure_dir(cfg.RESULTS_DIR)

    label_map = json.loads(
        (cfg.DATA_PROCESSED_DIR / "label_encoder.json").read_text(encoding="utf-8")
    )
    labels = [label_map[str(i)] for i in range(len(label_map))]

    y  = np.load(cfg.DATA_PROCESSED_DIR / "y.npy")
    X1 = sparse.load_npz(cfg.DATA_PROCESSED_DIR / "X_1gram.npz")
    X2 = sparse.load_npz(cfg.DATA_PROCESSED_DIR / "X_2gram.npz")

    print(f"[+] y={y.shape}  X1={X1.shape}  X2={X2.shape}  classes={len(labels)}")
    print(f"[+] KNN k-values : {cfg.KNN_K_VALUES}")
    print()

    print("[*] 1-gram experiments ...")
    r1 = run_cv("1gram", X1, y, labels)
    print("[*] 2-gram experiments ...")
    r2 = run_cv("2gram", X2, y, labels)

    (cfg.RESULTS_DIR / "metrics_1gram.json").write_text(
        json.dumps(r1, indent=2), encoding="utf-8"
    )
    (cfg.RESULTS_DIR / "metrics_2gram.json").write_text(
        json.dumps(r2, indent=2), encoding="utf-8"
    )

    out_csv = cfg.RESULTS_DIR / "summary_table.csv"
    with out_csv.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["features", "model", "mean_accuracy", "std_accuracy",
                    "mean_macro_precision", "mean_macro_recall", "mean_macro_f1"])
        for feats, obj in [("1gram", r1), ("2gram", r2)]:
            for m in obj["models"]:
                w.writerow([feats, m["model"],
                            m["mean"]["accuracy"],    m["std"]["accuracy"],
                            m["mean"]["macro_precision"], m["mean"]["macro_recall"],
                            m["mean"]["macro_f1"]])

    # Console summary
    print()
    print("=" * 72)
    print(f"{'Features':<8} {'Model':<16} {'Accuracy':>10} {'Precision':>10}"
          f" {'Recall':>8} {'F1':>8}")
    print("-" * 72)
    for feats, obj in [("1gram", r1), ("2gram", r2)]:
        for m in obj["models"]:
            print(f"{feats:<8} {m['model']:<16}"
                  f" {m['mean']['accuracy']:>10.4f}"
                  f" {m['mean']['macro_precision']:>10.4f}"
                  f" {m['mean']['macro_recall']:>8.4f}"
                  f" {m['mean']['macro_f1']:>8.4f}")
    print("=" * 72)


if __name__ == "__main__":
    main()
