#!/usr/bin/env python3
"""
01_build_manifest.py — Build the sample manifest linking OpCode files to APT labels
====================================================================================
Walks the Submission 2 Executable_Malware/ directory to extract APT group labels
(sub-folder names), then matches each label to the corresponding .opcode file
produced by the Submission 3 disassembly pipeline.

Output
------
    data_processed/manifest.csv   — sample_id | label | opcode_path

Usage
-----
    python -m scripts.01_build_manifest

Course    : CIS 6530 — Cybersecurity and Threat Intelligence
Submission: 4 — Multi-class OpCode Classification
"""

import csv
from scripts import config as cfg
from scripts.utils import ensure_dir


def main() -> None:
    ensure_dir(cfg.DATA_PROCESSED_DIR)

    # Build stem → label mapping from Submission 2 folder structure
    stem_to_label: dict = {}
    for p in cfg.SUB2_EXEC_ROOT.rglob("*"):
        if p.is_file() and p.suffix.lower() in [".exe", ".dll", ".elf"]:
            stem_to_label[p.stem] = p.parent.name

    # Match each .opcode file to its label
    rows: list = []
    for op in sorted(cfg.SUB3_RAW_OPCODES.glob("*.opcode")):
        stem  = op.stem
        label = stem_to_label.get(stem, "UNKNOWN")
        rows.append((stem, label, str(op)))

    out_csv = cfg.DATA_PROCESSED_DIR / "manifest.csv"
    with out_csv.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["sample_id", "label", "opcode_path"])
        w.writerows(rows)

    unknown = sum(1 for _, lab, _ in rows if lab == "UNKNOWN")
    print(f"[+] Manifest written : {out_csv}")
    print(f"[+] Total rows       : {len(rows)}")
    print(f"[!] UNKNOWN labels   : {unknown}  (should be 0)")


if __name__ == "__main__":
    main()
