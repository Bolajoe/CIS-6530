#!/usr/bin/env python3
"""
02_preprocess_vectorize.py — Parse .opcode files and build n-gram feature matrices
====================================================================================
Reads the manifest, parses each .opcode file into mnemonic token sequences,
filters classes with insufficient samples for cross-validation, and vectorises
the corpus into 1-gram and 2-gram count feature matrices.

Preprocessing rules
-------------------
* Lines starting with '#' (disassembler metadata) are discarded.
* Lines equal to '<FUNCTION>' (boundary markers) are discarded.
* All other non-empty lines are treated as single mnemonic tokens.
  Operands and addresses are intentionally stripped for a representation
  stable across compilation variants.

Class filtering
---------------
Labels with fewer than N_SPLITS (= 2) samples are excluded before modelling.
This is a requirement of StratifiedKFold: every fold must contain at least
one example of each class. Excluded labels are logged to
data_processed/filtered_out_classes.csv.

Leakage note
------------
The CountVectorizer objects serialised here are fitted on the full retained
corpus and are provided for dataset inspection only. The cross-validation
script (03) re-fits a fresh vectorizer on each training fold to prevent
test-vocabulary leakage.

Outputs
-------
    data_processed/ids.json
    data_processed/y.npy
    data_processed/label_encoder.json
    data_processed/X_1gram.npz          (59 × 542)
    data_processed/X_2gram.npz          (59 × 10,063)
    data_processed/vectorizer_1gram.pkl
    data_processed/vectorizer_2gram.pkl
    data_processed/class_counts.csv
    data_processed/filtered_out_classes.csv

Usage
-----
    python -m scripts.02_preprocess_vectorize   (run after 01)

Course    : CIS 6530 — Cybersecurity and Threat Intelligence
Submission: 4 — Multi-class OpCode Classification
"""

import csv
import json
from collections import Counter
from pathlib import Path

import numpy as np
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.preprocessing import LabelEncoder
from scipy import sparse
import joblib

from scripts import config as cfg
from scripts.utils import ensure_dir


def load_tokens(path: Path) -> list:
    """Return a list of opcode mnemonic strings from a single .opcode file."""
    tokens: list = []
    for line in path.read_text(errors="ignore").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or line.startswith("<FUNCTION>"):
            continue
        tokens.append(line)
    return tokens


def main() -> None:
    ensure_dir(cfg.DATA_PROCESSED_DIR)

    manifest = cfg.DATA_PROCESSED_DIR / "manifest.csv"
    if not manifest.exists():
        raise FileNotFoundError(
            "manifest.csv not found. Run: python -m scripts.01_build_manifest"
        )

    with manifest.open("r", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))

    # ── Class filtering ───────────────────────────────────────────────────
    label_counts: Counter = Counter(row["label"] for row in rows)
    keep_labels = {lab for lab, c in label_counts.items() if c >= cfg.N_SPLITS}
    drop_labels = {lab for lab, c in label_counts.items() if c <  cfg.N_SPLITS}

    filtered_rows = [row for row in rows if row["label"] in keep_labels]
    dropped_rows  = [row for row in rows if row["label"] in drop_labels]

    out_dropped = cfg.DATA_PROCESSED_DIR / "filtered_out_classes.csv"
    with out_dropped.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["sample_id", "label", "opcode_path"])
        for row in dropped_rows:
            w.writerow([row["sample_id"], row["label"], row["opcode_path"]])

    out_counts = cfg.DATA_PROCESSED_DIR / "class_counts.csv"
    with out_counts.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["label", "count", "kept"])
        for lab, c in sorted(label_counts.items(), key=lambda x: (-x[1], x[0])):
            w.writerow([lab, c, "yes" if lab in keep_labels else "no"])

    print(f"[+] Total samples in manifest  : {len(rows)}")
    print(f"[+] Kept samples (n >= {cfg.N_SPLITS})      : {len(filtered_rows)}")
    print(f"[!] Filtered samples (n < {cfg.N_SPLITS})   : {len(dropped_rows)}")
    print(f"[!] Filtered labels            : {sorted(drop_labels)}")

    # ── Parse .opcode files ───────────────────────────────────────────────
    ids, labels, texts = [], [], []
    for row in filtered_rows:
        tokens = load_tokens(Path(row["opcode_path"]))
        ids.append(row["sample_id"])
        labels.append(row["label"])
        texts.append(" ".join(tokens))

    le = LabelEncoder()
    y  = le.fit_transform(labels)

    (cfg.DATA_PROCESSED_DIR / "ids.json").write_text(
        json.dumps(ids, indent=2), encoding="utf-8"
    )
    label_map = {int(i): cls for i, cls in enumerate(le.classes_)}
    (cfg.DATA_PROCESSED_DIR / "label_encoder.json").write_text(
        json.dumps(label_map, indent=2), encoding="utf-8"
    )
    np.save(cfg.DATA_PROCESSED_DIR / "y.npy", y)

    # ── Vectorise ─────────────────────────────────────────────────────────
    vec1 = CountVectorizer(ngram_range=(1, 1), token_pattern=r"(?u)\b\w+\b")
    X1   = vec1.fit_transform(texts)
    joblib.dump(vec1, cfg.DATA_PROCESSED_DIR / "vectorizer_1gram.pkl")
    sparse.save_npz(cfg.DATA_PROCESSED_DIR / "X_1gram.npz", X1)

    vec2 = CountVectorizer(ngram_range=(2, 2), token_pattern=r"(?u)\b\w+\b")
    X2   = vec2.fit_transform(texts)
    joblib.dump(vec2, cfg.DATA_PROCESSED_DIR / "vectorizer_2gram.pkl")
    sparse.save_npz(cfg.DATA_PROCESSED_DIR / "X_2gram.npz", X2)

    sp1 = 1.0 - X1.nnz / (X1.shape[0] * X1.shape[1])
    sp2 = 1.0 - X2.nnz / (X2.shape[0] * X2.shape[1])
    print(f"[+] 1-gram : shape={X1.shape}, vocab={len(vec1.vocabulary_)}, sparsity={sp1:.4f}")
    print(f"[+] 2-gram : shape={X2.shape}, vocab={len(vec2.vocabulary_)}, sparsity={sp2:.4f}")
    print("[+] Preprocessing complete.")


if __name__ == "__main__":
    main()
