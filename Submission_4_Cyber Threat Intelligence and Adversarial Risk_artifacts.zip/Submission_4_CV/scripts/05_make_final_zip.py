#!/usr/bin/env python3
"""
05_make_final_zip.py — Package all deliverables into the submission ZIP
========================================================================
Assembles Submission_4_Artifacts.zip containing scripts/, data_processed/,
results/, README.md, and requirements.txt. Excludes __pycache__ and .pyc files.

Usage
-----
    python -m scripts.05_make_final_zip   (run after 01–04)

Course    : CIS 6530 — Cybersecurity and Threat Intelligence
Submission: 4 — Multi-class OpCode Classification
"""

import zipfile
from pathlib import Path
from scripts import config as cfg

EXCLUDE = {"__pycache__", ".pyc", ".pyo", ".DS_Store", "Thumbs.db"}


def should_include(p: Path) -> bool:
    return not any(ex in str(p) for ex in EXCLUDE)


def add_dir(z: zipfile.ZipFile, folder: Path, arc_prefix: str) -> int:
    count = 0
    for p in sorted(folder.rglob("*")):
        if p.is_file() and should_include(p):
            z.write(p, str(Path(arc_prefix) / p.relative_to(folder)))
            count += 1
    return count


def main() -> None:
    out_zip = cfg.PROJECT_ROOT / "Submission_4_Artifacts.zip"
    if out_zip.exists():
        out_zip.unlink()

    total = 0
    with zipfile.ZipFile(out_zip, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for folder, prefix in [
            (cfg.PROJECT_ROOT / "scripts",   "scripts"),
            (cfg.DATA_PROCESSED_DIR,          "data_processed"),
            (cfg.RESULTS_DIR,                 "results"),
        ]:
            if folder.exists():
                n = add_dir(z, folder, prefix)
                print(f"[+] {prefix:<16}: {n} file(s)")
                total += n
        for fname in ["README.md", "requirements.txt"]:
            p = cfg.PROJECT_ROOT / fname
            if p.exists():
                z.write(p, fname)
                total += 1
                print(f"[+] {fname}")

    size_mb = out_zip.stat().st_size / (1024 * 1024)
    print(f"\n[+] Wrote {out_zip}  ({size_mb:.2f} MB, {total} files)")


if __name__ == "__main__":
    main()
