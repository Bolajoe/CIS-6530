#!/usr/bin/env python3
"""
04_plot_metrics.py — Generate all performance plots and confusion matrices
==========================================================================
Reads the JSON results produced by 03_train_eval_models.py and generates:

    1. Aggregated confusion matrix — one PNG per classifier × feature set
       (10 total: SVM, KNN k=3/4/5, DecisionTree × 1-gram/2-gram)
    2. Bar charts — Accuracy, Macro-Precision, Macro-Recall, Macro-F1
       comparing all classifiers across both feature sets
    3. Grouped comparison charts — 1-gram vs 2-gram per classifier
       for Accuracy and Macro-F1

All figures are saved at 200 dpi with a consistent IEEE-compatible style.

Outputs
-------
    results/confusion_{Model}_{feature_set}.png   (10 files)
    results/bar_accuracy.png
    results/bar_precision.png
    results/bar_recall.png
    results/bar_f1.png
    results/compare_accuracy.png
    results/compare_f1.png

Usage
-----
    python -m scripts.04_plot_metrics   (run after 03)

Course    : CIS 6530 — Cybersecurity and Threat Intelligence
Submission: 4 — Multi-class OpCode Classification
"""

import json
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
from sklearn.metrics import ConfusionMatrixDisplay

from scripts import config as cfg
from scripts.utils import ensure_dir


# ── Style ──────────────────────────────────────────────────────────────────
MODEL_COLOURS = {
    "SVM_Linear":    "#1F4E79",
    "KNN_k3":        "#70AD47",
    "KNN_k4":        "#ED7D31",
    "KNN_k5":        "#C55A11",
    "DecisionTree":  "#375623",
}
COLOUR_1G = "#2E75B6"
COLOUR_2G = "#ED7D31"

plt.rcParams.update({
    "figure.dpi":        100,
    "font.family":       "serif",
    "font.size":         11,
    "axes.titlesize":    12,
    "axes.labelsize":    11,
    "xtick.labelsize":   9,
    "ytick.labelsize":   9,
    "axes.spines.top":   False,
    "axes.spines.right": False,
})


def load_labels() -> list:
    label_map = json.loads(
        (cfg.DATA_PROCESSED_DIR / "label_encoder.json").read_text(encoding="utf-8")
    )
    return [label_map[str(i)] for i in range(len(label_map))]


def load_results(json_path) -> dict:
    return json.loads(json_path.read_text(encoding="utf-8"))


def short_name(name: str) -> str:
    mapping = {
        "SVM_Linear":   "LinearSVC",
        "KNN_k3":       "KNN (k=3)",
        "KNN_k4":       "KNN (k=4)",
        "KNN_k5":       "KNN (k=5)",
        "DecisionTree": "Dec. Tree",
    }
    return mapping.get(name, name)


# ── Confusion matrices ──────────────────────────────────────────────────────

def plot_confusion_matrices(obj: dict, labels: list) -> None:
    feat = obj["feature_set"]
    for m in obj["models"]:
        cm   = np.array(m["confusion_matrix_sum"])
        fig, ax = plt.subplots(figsize=(12, 9))
        disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=labels)
        disp.plot(ax=ax, xticks_rotation=90, values_format="d", colorbar=True)
        ax.set_title(
            f"{short_name(m['model'])} — {feat}\n"
            f"Aggregated over {obj['cv']['n_splits']} stratified folds  "
            f"({obj['n_classes']} classes, {obj['n_samples']} samples)",
            pad=14,
        )
        fig.tight_layout()
        safe = m["model"].replace("/", "_")
        out  = cfg.RESULTS_DIR / f"confusion_{safe}_{feat}.png"
        fig.savefig(out, dpi=200, bbox_inches="tight")
        plt.close(fig)
        print(f"[+] Wrote {out}")


# ── Single-metric bar chart ─────────────────────────────────────────────────

def plot_metric_bar(r1: dict, r2: dict, metric_key: str,
                    ylabel: str, title: str, out_name: str) -> None:
    names  = [m["model"] for m in r1["models"]]
    x      = np.arange(len(names))
    width  = 0.35

    fig, ax = plt.subplots(figsize=(9, 5))
    bars1 = ax.bar(x - width/2,
                   [m["mean"][metric_key] for m in r1["models"]],
                   width, label="1-gram", color=COLOUR_1G, alpha=0.9, edgecolor="white")
    bars2 = ax.bar(x + width/2,
                   [m["mean"][metric_key] for m in r2["models"]],
                   width, label="2-gram", color=COLOUR_2G, alpha=0.9, edgecolor="white")

    for bar in list(bars1) + list(bars2):
        h = bar.get_height()
        ax.annotate(f"{h:.3f}",
                    xy=(bar.get_x() + bar.get_width() / 2, h),
                    xytext=(0, 3), textcoords="offset points",
                    ha="center", va="bottom", fontsize=7.5)

    ax.set_xticks(x)
    ax.set_xticklabels([short_name(n) for n in names])
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.set_ylim(0, min(1.0, ax.get_ylim()[1] * 1.18))
    ax.yaxis.set_major_formatter(mticker.FormatStrFormatter("%.2f"))
    ax.legend(framealpha=0.7)
    fig.tight_layout()

    out = cfg.RESULTS_DIR / f"{out_name}.png"
    fig.savefig(out, dpi=200, bbox_inches="tight")
    plt.close(fig)
    print(f"[+] Wrote {out}")


# ── 1-gram vs 2-gram grouped comparison ────────────────────────────────────

def plot_gram_comparison(r1: dict, r2: dict, metric_key: str,
                         ylabel: str, title: str, out_name: str) -> None:
    names  = [m["model"] for m in r1["models"]]
    vals1  = [m["mean"][metric_key] for m in r1["models"]]
    vals2  = [m["mean"][metric_key] for m in r2["models"]]
    x      = np.arange(len(names))
    width  = 0.35

    fig, ax = plt.subplots(figsize=(9, 5))
    bars1 = ax.bar(x - width/2, vals1, width, label="1-gram",
                   color=COLOUR_1G, alpha=0.9, edgecolor="white")
    bars2 = ax.bar(x + width/2, vals2, width, label="2-gram",
                   color=COLOUR_2G, alpha=0.9, edgecolor="white")

    for bar in list(bars1) + list(bars2):
        h = bar.get_height()
        ax.annotate(f"{h:.3f}",
                    xy=(bar.get_x() + bar.get_width() / 2, h),
                    xytext=(0, 3), textcoords="offset points",
                    ha="center", va="bottom", fontsize=7.5)

    ax.set_xticks(x)
    ax.set_xticklabels([short_name(n) for n in names])
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.set_ylim(0, min(1.0, max(max(vals1), max(vals2)) * 1.25))
    ax.legend(framealpha=0.7)
    fig.tight_layout()

    out = cfg.RESULTS_DIR / f"{out_name}.png"
    fig.savefig(out, dpi=200, bbox_inches="tight")
    plt.close(fig)
    print(f"[+] Wrote {out}")


# ── Main ────────────────────────────────────────────────────────────────────

def main() -> None:
    ensure_dir(cfg.RESULTS_DIR)
    labels = load_labels()
    r1     = load_results(cfg.RESULTS_DIR / "metrics_1gram.json")
    r2     = load_results(cfg.RESULTS_DIR / "metrics_2gram.json")

    print("[*] Generating confusion matrices (10 figures) ...")
    plot_confusion_matrices(r1, labels)
    plot_confusion_matrices(r2, labels)

    print("[*] Generating metric bar charts ...")
    plot_metric_bar(r1, r2, "accuracy",
                    "Mean Accuracy (2-fold CV)",
                    "Accuracy by Classifier and Feature Set", "bar_accuracy")
    plot_metric_bar(r1, r2, "macro_precision",
                    "Macro Precision (2-fold CV)",
                    "Macro-Precision by Classifier and Feature Set", "bar_precision")
    plot_metric_bar(r1, r2, "macro_recall",
                    "Macro Recall (2-fold CV)",
                    "Macro-Recall by Classifier and Feature Set", "bar_recall")
    plot_metric_bar(r1, r2, "macro_f1",
                    "Macro F1 (2-fold CV)",
                    "Macro-F1 by Classifier and Feature Set", "bar_f1")

    print("[*] Generating 1-gram vs 2-gram comparison charts ...")
    plot_gram_comparison(r1, r2, "accuracy",
                         "Mean Accuracy",
                         "Accuracy: 1-Gram vs 2-Gram", "compare_accuracy")
    plot_gram_comparison(r1, r2, "macro_f1",
                         "Macro F1",
                         "Macro-F1: 1-Gram vs 2-Gram", "compare_f1")

    print("[+] All plots complete.")


if __name__ == "__main__":
    main()
