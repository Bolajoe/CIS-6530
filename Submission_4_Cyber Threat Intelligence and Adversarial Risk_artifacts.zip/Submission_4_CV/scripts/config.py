"""
config.py — Centralised configuration for CIS 6530 Submission 4
================================================================
All user-configurable paths and experiment hyper-parameters live here.
Update SUB3_OUTPUT and SUB2_ROOT to match your local installation, then
run the pipeline scripts in numerical order (01 → 05).

Course    : CIS 6530 — Cybersecurity and Threat Intelligence
Submission: 4 — Multi-class OpCode Classification
Date      : March 2026
"""

from pathlib import Path

# ---------------------------------------------------------------------------
# USER PATHS — UPDATE THESE TO MATCH YOUR ENVIRONMENT
# ---------------------------------------------------------------------------
# Root of the Submission 3 output directory (contains Raw_Extracted_Files/)
SUB3_OUTPUT = Path(r"/home/kali/Desktop/SUBMISSION_3_OUTPUT")

# Root of the Submission 2 deliverable directory (contains Executable_Malware/)
SUB2_ROOT = Path(r"/home/kali/Desktop/cis6530 folder/CIS_6530_Assignment_Submission_2")

# ---------------------------------------------------------------------------
# DERIVED LOCATIONS  (do not edit unless folder structure changes)
# ---------------------------------------------------------------------------
SUB3_RAW_OPCODES: Path = SUB3_OUTPUT / "Raw_Extracted_Files"
SUB2_EXEC_ROOT:   Path = SUB2_ROOT   / "Executable_Malware"

# ---------------------------------------------------------------------------
# LOCAL PROJECT PATHS (relative to this repo — do not edit)
# ---------------------------------------------------------------------------
PROJECT_ROOT:       Path = Path(__file__).resolve().parents[1]
DATA_PROCESSED_DIR: Path = PROJECT_ROOT / "data_processed"
RESULTS_DIR:        Path = PROJECT_ROOT / "results"

# ---------------------------------------------------------------------------
# EXPERIMENT CONFIGURATION
# ---------------------------------------------------------------------------
# Reproducibility seed — applied to all stochastic components
RANDOM_SEED: int = 42

# Cross-validation folds.
# Set to 2 because many APT labels have exactly 2 samples; higher values
# would create training partitions with insufficient class support.
N_SPLITS: int = 2

# KNN — rubric specifies k in {3, 4, 5}; all three values are evaluated.
KNN_K_VALUES: list = [3, 4, 5]
