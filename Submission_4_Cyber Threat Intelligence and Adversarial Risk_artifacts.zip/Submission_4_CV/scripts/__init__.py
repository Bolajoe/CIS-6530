# scripts/__init__.py — makes `scripts` a Python package
