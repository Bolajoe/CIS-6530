"""
utils.py — Shared utility helpers for CIS 6530 Submission 4 pipeline
"""
from pathlib import Path


def ensure_dir(p: Path) -> None:
    """Create *p* and all intermediate parent directories if they do not exist."""
    p.mkdir(parents=True, exist_ok=True)
